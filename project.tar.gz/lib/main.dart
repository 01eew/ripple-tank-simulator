// ╔══════════════════════════════════════════════════════════════╗
// ║  Ripple Tank Simulator — محاكي حوض الأمواج التفاعلي          ║
// ║  برمجة وتطوير: حسين خالد حميد                                ║
// ║  هندسة الأمن السيبراني — جامعة المعقل                        ║
// ║  أستاذ المادة: د. أحمد دنقل                                  ║
// ║  Flutter & Dart — no external packages                       ║
// ╚══════════════════════════════════════════════════════════════╝

import 'package:flutter/material.dart';

import 'credits.dart';
import 'theme.dart';
import 'ui/splash_screen.dart';

void main() {
  runApp(const RippleTankApp());
}

class RippleTankApp extends StatelessWidget {
  const RippleTankApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: Credits.appName,
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),
      home: const SplashScreen(),
    );
  }
}
