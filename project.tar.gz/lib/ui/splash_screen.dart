import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../credits.dart';
import '../theme.dart';
import 'home_screen.dart';
import 'widgets.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with TickerProviderStateMixin {
  late final AnimationController _intro =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 2600))
        ..forward();
  late final AnimationController _loop =
      AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();

  bool _started = false;

  @override
  void initState() {
    super.initState();
    // auto-continue after the intro
    Future.delayed(const Duration(seconds: 6), () {
      if (mounted) _start();
    });
  }

  @override
  void dispose() {
    _intro.dispose();
    _loop.dispose();
    super.dispose();
  }

  Animation<double> _iv(double a, double b) => CurvedAnimation(
        parent: _intro,
        curve: Interval(a, b, curve: Curves.easeOutCubic),
      );

  void _start() {
    if (_started) return;
    _started = true;
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 900),
      pageBuilder: (context, a, b) => const HomeScreen(),
      transitionsBuilder: (context, a, b, child) {
        final c = CurvedAnimation(parent: a, curve: Curves.easeOutCubic);
        return FadeTransition(
          opacity: c,
          child: ScaleTransition(scale: Tween(begin: 1.06, end: 1.0).animate(c), child: child),
        );
      },
    ));
  }

  Widget _fadeUp(Animation<double> a, Widget child) => AnimatedBuilder(
        animation: a,
        builder: (context, c) => Opacity(
          opacity: a.value,
          child: Transform.translate(offset: Offset(0, 24 * (1 - a.value)), child: c),
        ),
        child: child,
      );

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.sizeOf(context).width;
    final big = w > 600;
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          const AuroraBackground(),
          AnimatedBuilder(
            animation: _loop,
            builder: (context, _) => CustomPaint(painter: _RipplesPainter(_loop.value)),
          ),
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 520),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      ScaleTransition(
                        scale: _iv(0.0, 0.35),
                        child: LogoMark(size: big ? 110 : 92),
                      ),
                      const SizedBox(height: 22),
                      _fadeUp(
                        _iv(0.15, 0.45),
                        GradientText(
                          'RIPPLE TANK',
                          style: TextStyle(
                            fontSize: big ? 46 : 36,
                            fontWeight: FontWeight.w900,
                            letterSpacing: 6,
                          ),
                        ),
                      ),
                      _fadeUp(
                        _iv(0.22, 0.5),
                        Text(
                          'محاكي حوض الأمواج التفاعلي',
                          style: TextStyle(
                            fontSize: big ? 22 : 18,
                            fontWeight: FontWeight.w700,
                            color: AppColors.text,
                          ),
                        ),
                      ),
                      const SizedBox(height: 6),
                      _fadeUp(
                        _iv(0.28, 0.56),
                        const Text(
                          'Reflection • Diffraction • Scattering • Refraction',
                          textAlign: TextAlign.center,
                          style: TextStyle(color: AppColors.textDim, fontSize: 13, letterSpacing: 0.5),
                        ),
                      ),
                      const SizedBox(height: 30),
                      _fadeUp(
                        _iv(0.4, 0.75),
                        GlassCard(
                          glow: AppColors.violet,
                          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 20),
                          child: Column(
                            children: [
                              const Text('برمجة وتطوير',
                                  style: TextStyle(color: AppColors.textDim, fontSize: 13)),
                              const SizedBox(height: 6),
                              GradientText(
                                Credits.developer,
                                style: TextStyle(
                                  fontSize: big ? 30 : 26,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 10),
                              Container(height: 1, color: Colors.white.withValues(alpha: 0.1)),
                              const SizedBox(height: 12),
                              _info(Icons.security_rounded, Credits.major),
                              const SizedBox(height: 6),
                              _info(Icons.school_rounded, Credits.university),
                              const SizedBox(height: 6),
                              _info(Icons.person_rounded, 'بإشراف ${Credits.supervisor}'),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(height: 30),
                      _fadeUp(
                        _iv(0.65, 1.0),
                        AnimatedBuilder(
                          animation: _loop,
                          builder: (context, child) {
                            final p = 0.5 + 0.5 * math.sin(_loop.value * 2 * math.pi * 2);
                            return Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(40),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.cyan.withValues(alpha: 0.25 + 0.25 * p),
                                    blurRadius: 18 + 14 * p,
                                  ),
                                ],
                              ),
                              child: child,
                            );
                          },
                          child: Pressable(
                            onTap: _start,
                            child: Container(
                              padding: const EdgeInsets.symmetric(horizontal: 34, vertical: 16),
                              decoration: BoxDecoration(
                                gradient: AppColors.brand,
                                borderRadius: BorderRadius.circular(40),
                              ),
                              child: const Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text('ابدأ المحاكاة',
                                      style: TextStyle(
                                          fontSize: 17,
                                          fontWeight: FontWeight.w800,
                                          color: Colors.white)),
                                  SizedBox(width: 10),
                                  Icon(Icons.waves_rounded, color: Colors.white),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _info(IconData icon, String text) => Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 17, color: AppColors.cyan),
          const SizedBox(width: 8),
          Flexible(
            child: Text(text,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 14.5, color: AppColors.text)),
          ),
        ],
      );
}

class _RipplesPainter extends CustomPainter {
  _RipplesPainter(this.t);
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final centers = [
      Offset(size.width * 0.38, size.height * 0.22),
      Offset(size.width * 0.62, size.height * 0.22),
    ];
    final maxR = math.max(size.width, size.height) * 0.9;
    for (final c in centers) {
      for (int k = 0; k < 7; k++) {
        final p = (t + k / 7) % 1.0;
        canvas.drawCircle(
          c,
          maxR * p,
          Paint()
            ..style = PaintingStyle.stroke
            ..strokeWidth = 1.4
            ..color = AppColors.cyan.withValues(alpha: 0.16 * (1 - p)),
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant _RipplesPainter old) => old.t != t;
}
