import 'package:flutter/material.dart';

import '../credits.dart';
import '../engine/sim_objects.dart';
import '../sim_controller.dart';
import '../theme.dart';
import 'about_sheet.dart';
import 'widgets.dart';

class ControlPanel extends StatefulWidget {
  const ControlPanel({super.key, required this.c, this.compact = false});
  final SimController c;
  final bool compact;

  @override
  State<ControlPanel> createState() => _ControlPanelState();
}

class _ControlPanelState extends State<ControlPanel> {
  int _tab = 0;
  static const _tabs = [
    (Icons.science_rounded, 'التجارب'),
    (Icons.category_rounded, 'الأدوات'),
    (Icons.tune_rounded, 'التحكم'),
  ];

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.fromLTRB(12, 12, 12, 10),
      child: Column(
        children: [
          _TabBar(
            tabs: _tabs,
            index: _tab,
            onChanged: (i) => setState(() => _tab = i),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 380),
              switchInCurve: Curves.easeOutCubic,
              transitionBuilder: (child, a) => FadeTransition(
                opacity: a,
                child: SlideTransition(
                  position: Tween(begin: const Offset(0, 0.04), end: Offset.zero).animate(a),
                  child: child,
                ),
              ),
              child: KeyedSubtree(
                key: ValueKey(_tab),
                child: switch (_tab) {
                  0 => _PresetsTab(c: widget.c),
                  1 => _ToolsTab(c: widget.c),
                  _ => _ControlsTab(c: widget.c),
                },
              ),
            ),
          ),
          const SizedBox(height: 8),
          const _CreditFooter(),
        ],
      ),
    );
  }
}

// ------------------------------------------------------------------ tab bar

class _TabBar extends StatelessWidget {
  const _TabBar({required this.tabs, required this.index, required this.onChanged});
  final List<(IconData, String)> tabs;
  final int index;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 46,
      padding: const EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.25),
        borderRadius: BorderRadius.circular(16),
      ),
      child: LayoutBuilder(builder: (context, box) {
        final w = box.maxWidth / tabs.length;
        final rtl = Directionality.of(context) == TextDirection.rtl;
        return Stack(
          children: [
            AnimatedPositioned(
              duration: const Duration(milliseconds: 380),
              curve: Curves.easeOutBack,
              left: rtl ? (tabs.length - 1 - index) * w : index * w,
              top: 0,
              bottom: 0,
              width: w,
              child: Container(
                decoration: BoxDecoration(
                  gradient: AppColors.brand,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(color: AppColors.cyan.withValues(alpha: 0.35), blurRadius: 12),
                  ],
                ),
              ),
            ),
            Row(
              children: [
                for (int i = 0; i < tabs.length; i++)
                  Expanded(
                    child: Pressable(
                      onTap: () => onChanged(i),
                      child: Center(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(tabs[i].$1,
                                size: 17,
                                color: i == index ? Colors.white : AppColors.textDim),
                            const SizedBox(width: 6),
                            AnimatedDefaultTextStyle(
                              duration: const Duration(milliseconds: 250),
                              style: TextStyle(
                                fontSize: 13.5,
                                fontWeight: i == index ? FontWeight.w800 : FontWeight.w500,
                                color: i == index ? Colors.white : AppColors.textDim,
                              ),
                              child: Text(tabs[i].$2),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ],
        );
      }),
    );
  }
}

// ------------------------------------------------------------------ presets

class _PresetsTab extends StatelessWidget {
  const _PresetsTab({required this.c});
  final SimController c;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: c,
      builder: (context, _) => ListView.separated(
        padding: EdgeInsets.zero,
        itemCount: presets.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (context, i) {
          final p = presets[i];
          final sel = c.presetIndex == i;
          return StaggerIn(
            index: i,
            child: Pressable(
              onTap: () => c.loadPreset(i),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: sel
                      ? p.colors.first.withValues(alpha: 0.14)
                      : Colors.white.withValues(alpha: 0.04),
                  border: Border.all(
                    color: sel
                        ? p.colors.first.withValues(alpha: 0.8)
                        : Colors.white.withValues(alpha: 0.07),
                    width: sel ? 1.4 : 1,
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(13),
                        gradient: LinearGradient(colors: p.colors),
                        boxShadow: [
                          BoxShadow(color: p.colors.first.withValues(alpha: 0.4), blurRadius: 10),
                        ],
                      ),
                      child: Icon(p.icon, color: Colors.white, size: 22),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Flexible(
                                child: Text(p.ar,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w800, fontSize: 14.5)),
                              ),
                              const SizedBox(width: 6),
                              Text(p.en,
                                  style: const TextStyle(
                                      fontSize: 10.5, color: AppColors.textDim)),
                            ],
                          ),
                          const SizedBox(height: 2),
                          Text(p.desc,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(fontSize: 11.5, color: AppColors.textDim)),
                        ],
                      ),
                    ),
                    AnimatedOpacity(
                      opacity: sel ? 1 : 0,
                      duration: const Duration(milliseconds: 250),
                      child: Icon(Icons.play_circle_fill_rounded, color: p.colors.first),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}

// -------------------------------------------------------------------- tools

class _ToolsTab extends StatelessWidget {
  const _ToolsTab({required this.c});
  final SimController c;

  @override
  Widget build(BuildContext context) {
    const kinds = ObjKind.values;
    return LayoutBuilder(builder: (context, box) {
      final cols = box.maxWidth > 420 ? 4 : 3;
      return CustomScrollView(
        slivers: [
          const SliverToBoxAdapter(
            child: Padding(
              padding: EdgeInsets.only(bottom: 10),
              child: Text(
                'اضغط على أداة لإضافتها، ثم اسحبها داخل الحوض. اضغط على أي جسم لتدويره أو حذفه.',
                style: TextStyle(fontSize: 12, color: AppColors.textDim),
              ),
            ),
          ),
          SliverGrid(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: cols,
              mainAxisSpacing: 8,
              crossAxisSpacing: 8,
              childAspectRatio: 1.05,
            ),
            delegate: SliverChildBuilderDelegate(
              (context, i) {
                final k = kinds[i];
                return StaggerIn(
                  index: i,
                  child: Pressable(
                    onTap: () => c.addFromToolbar(k),
                    tooltip: k.enName,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(16),
                        color: Colors.white.withValues(alpha: 0.05),
                        border: Border.all(color: Colors.white.withValues(alpha: 0.08)),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ShaderMask(
                            blendMode: BlendMode.srcIn,
                            shaderCallback: (r) => AppColors.brand.createShader(r),
                            child: Icon(k.icon, size: 28),
                          ),
                          const SizedBox(height: 6),
                          Text(k.arName,
                              textAlign: TextAlign.center,
                              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                        ],
                      ),
                    ),
                  ),
                );
              },
              childCount: kinds.length,
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.only(top: 12),
              child: Row(
                children: [
                  Expanded(
                    child: _ActionButton(
                      icon: Icons.cleaning_services_rounded,
                      label: 'مسح الأمواج',
                      onTap: c.clearWaves,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _ActionButton(
                      icon: Icons.delete_sweep_rounded,
                      label: 'حوض فارغ',
                      onTap: c.clearAll,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      );
    });
  }
}

class _ActionButton extends StatelessWidget {
  const _ActionButton({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      child: Container(
        height: 42,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Colors.white.withValues(alpha: 0.06),
          border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 18, color: AppColors.cyan),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          ],
        ),
      ),
    );
  }
}

// ----------------------------------------------------------------- controls

class _ControlsTab extends StatelessWidget {
  const _ControlsTab({required this.c});
  final SimController c;

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: c,
      builder: (context, _) {
        int i = 0;
        Widget s(Widget w) => StaggerIn(index: i++, child: w);
        return ListView(
          padding: EdgeInsets.zero,
          children: [
            s(_Section(
              title: 'نمط العرض',
              child: Row(
                children: [
                  Expanded(
                    child: _Segment(
                      icon: Icons.grid_on_rounded,
                      label: 'ثنائي 2D',
                      active: !c.view3D,
                      onTap: () => c.setView3D(false),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _Segment(
                      icon: Icons.view_in_ar_rounded,
                      label: 'مجسم 3D',
                      active: c.view3D,
                      onTap: () => c.setView3D(true),
                    ),
                  ),
                ],
              ),
            )),
            s(_Section(
              title: 'ألوان الموجة',
              child: Row(
                children: [
                  for (int k = 0; k < colorSchemes.length; k++)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 3),
                        child: Pressable(
                          onTap: () => c.setColorScheme(k),
                          child: Column(
                            children: [
                              AnimatedContainer(
                                duration: const Duration(milliseconds: 250),
                                height: 30,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(10),
                                  gradient: LinearGradient(colors: colorSchemes[k].swatch),
                                  border: Border.all(
                                    color: c.colorScheme == k ? Colors.white : Colors.transparent,
                                    width: 2,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(colorSchemes[k].name,
                                  style: TextStyle(
                                      fontSize: 11,
                                      color: c.colorScheme == k ? Colors.white : AppColors.textDim)),
                            ],
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            )),
            s(_SliderRow(
              icon: Icons.graphic_eq_rounded,
              title: 'تردد المصدر',
              value: c.frequency,
              min: 0.8,
              max: 7,
              display: '${c.frequency.toStringAsFixed(1)} Hz  •  λ≈${c.wavelengthCells.toStringAsFixed(0)}',
              onChanged: c.setFrequency,
            )),
            s(_SliderRow(
              icon: Icons.height_rounded,
              title: 'سعة المصدر',
              value: c.amplitude,
              min: 0.2,
              max: 2,
              display: c.amplitude.toStringAsFixed(2),
              onChanged: c.setAmplitude,
            )),
            s(_SliderRow(
              icon: Icons.speed_rounded,
              title: 'سرعة المحاكاة',
              value: c.speed.toDouble(),
              min: 1,
              max: 6,
              divisions: 5,
              display: '×${c.speed}',
              onChanged: (v) => c.setSpeed(v.round()),
            )),
            s(_SliderRow(
              icon: Icons.water_drop_outlined,
              title: 'التخميد',
              value: c.damping,
              min: 0,
              max: 1,
              display: '${(c.damping * 100).round()}%',
              onChanged: c.setDamping,
            )),
            s(_SliderRow(
              icon: Icons.light_mode_rounded,
              title: 'السطوع',
              value: c.brightness,
              min: 0.4,
              max: 4,
              display: c.brightness.toStringAsFixed(1),
              onChanged: c.setBrightness,
            )),
            if (c.view3D)
              s(_SliderRow(
                icon: Icons.terrain_rounded,
                title: 'ارتفاع السطح 3D',
                value: c.heightScale,
                min: 0.3,
                max: 2.5,
                display: c.heightScale.toStringAsFixed(1),
                onChanged: c.setHeightScale,
              )),
            s(_Section(
              title: 'حواف الحوض',
              child: Row(
                children: [
                  Expanded(
                    child: _Segment(
                      icon: Icons.blur_on_rounded,
                      label: 'ماصّة',
                      active: c.absorbingEdges,
                      onTap: () => c.setAbsorbingEdges(true),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: _Segment(
                      icon: Icons.border_outer_rounded,
                      label: 'عاكسة',
                      active: !c.absorbingEdges,
                      onTap: () => c.setAbsorbingEdges(false),
                    ),
                  ),
                ],
              ),
            )),
            s(Padding(
              padding: const EdgeInsets.only(top: 4, bottom: 6),
              child: _ActionButton(
                icon: Icons.info_outline_rounded,
                label: 'حول التطبيق والمحرك الفيزيائي',
                onTap: () => showAbout(context),
              ),
            )),
          ],
        );
      },
    );
  }
}

class _Section extends StatelessWidget {
  const _Section({required this.title, required this.child});
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: const TextStyle(
                  fontSize: 12.5, color: AppColors.textDim, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          child,
        ],
      ),
    );
  }
}

class _Segment extends StatelessWidget {
  const _Segment({required this.icon, required this.label, required this.active, required this.onTap});
  final IconData icon;
  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 280),
        height: 40,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: active ? AppColors.brand : null,
          color: active ? null : Colors.white.withValues(alpha: 0.05),
          border: Border.all(color: Colors.white.withValues(alpha: active ? 0 : 0.08)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 17, color: active ? Colors.white : AppColors.textDim),
            const SizedBox(width: 6),
            Text(label,
                style: TextStyle(
                    fontSize: 13,
                    fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                    color: active ? Colors.white : AppColors.textDim)),
          ],
        ),
      ),
    );
  }
}

class _SliderRow extends StatelessWidget {
  const _SliderRow({
    required this.icon,
    required this.title,
    required this.value,
    required this.min,
    required this.max,
    required this.display,
    required this.onChanged,
    this.divisions,
  });
  final IconData icon;
  final String title;
  final double value, min, max;
  final String display;
  final ValueChanged<double> onChanged;
  final int? divisions;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Column(
        children: [
          Row(
            children: [
              Icon(icon, size: 16, color: AppColors.cyan),
              const SizedBox(width: 6),
              Text(title, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppColors.cyan.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(display,
                      style: const TextStyle(fontSize: 11.5, color: AppColors.cyan)),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 34,
            child: Slider(
              value: value.clamp(min, max),
              min: min,
              max: max,
              divisions: divisions,
              onChanged: onChanged,
            ),
          ),
        ],
      ),
    );
  }
}

// ----------------------------------------------------------------- credits

class _CreditFooter extends StatelessWidget {
  const _CreditFooter();

  @override
  Widget build(BuildContext context) {
    return Pressable(
      onTap: () => showAbout(context),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(14),
          color: Colors.black.withValues(alpha: 0.2),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.code_rounded, size: 16, color: AppColors.textDim),
            const SizedBox(width: 6),
            const Text('برمجة وتطوير: ',
                style: TextStyle(fontSize: 12, color: AppColors.textDim)),
            GradientText(Credits.developer,
                style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }
}
