import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../theme.dart';

/// Solid panel with a hairline border — the base surface of the app.
class Panel extends StatelessWidget {
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(14),
    this.radius = 18,
    this.color = AppColors.surface,
  });

  final Widget child;
  final EdgeInsets padding;
  final double radius;
  final Color color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: AppColors.stroke),
        boxShadow: const [
          BoxShadow(color: Color(0x66000000), blurRadius: 24, offset: Offset(0, 10)),
        ],
      ),
      child: child,
    );
  }
}

/// Fades + slides its child in after a staggered delay.
class StaggerIn extends StatefulWidget {
  const StaggerIn({super.key, required this.index, required this.child, this.offset = 16});
  final int index;
  final Widget child;
  final double offset;

  @override
  State<StaggerIn> createState() => _StaggerInState();
}

class _StaggerInState extends State<StaggerIn> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 480),
  );

  @override
  void initState() {
    super.initState();
    Future.delayed(Duration(milliseconds: 40 * widget.index), () {
      if (mounted) _c.forward();
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final a = CurvedAnimation(parent: _c, curve: Curves.easeOutCubic);
    return AnimatedBuilder(
      animation: a,
      builder: (context, child) => Opacity(
        opacity: a.value,
        child: Transform.translate(
          offset: Offset(0, (1 - a.value) * widget.offset),
          child: child,
        ),
      ),
      child: widget.child,
    );
  }
}

/// Scales down slightly while pressed.
class Pressable extends StatefulWidget {
  const Pressable({super.key, required this.child, this.onTap, this.tooltip});
  final Widget child;
  final VoidCallback? onTap;
  final String? tooltip;

  @override
  State<Pressable> createState() => _PressableState();
}

class _PressableState extends State<Pressable> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    Widget w = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => _down = true),
      onTapCancel: () => setState(() => _down = false),
      onTapUp: (_) => setState(() => _down = false),
      onTap: widget.onTap,
      child: AnimatedScale(
        scale: _down ? 0.94 : 1,
        duration: const Duration(milliseconds: 110),
        curve: Curves.easeOut,
        child: widget.child,
      ),
    );
    if (widget.tooltip != null) w = Tooltip(message: widget.tooltip!, child: w);
    return MouseRegion(cursor: SystemMouseCursors.click, child: w);
  }
}

/// Square icon button. [active] fills it with the brand colour.
class IconBtn extends StatelessWidget {
  const IconBtn({
    super.key,
    required this.icon,
    required this.onTap,
    this.tooltip,
    this.active = false,
    this.danger = false,
    this.size = 40,
  });
  final IconData icon;
  final VoidCallback onTap;
  final String? tooltip;
  final bool active;
  final bool danger;
  final double size;

  @override
  Widget build(BuildContext context) {
    final fg = active
        ? AppColors.onCyan
        : danger
            ? AppColors.coral
            : AppColors.text;
    return Pressable(
      onTap: onTap,
      tooltip: tooltip,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: active ? AppColors.cyan : AppColors.surfaceHi,
          borderRadius: BorderRadius.circular(size * 0.3),
          border: Border.all(color: active ? AppColors.cyan : AppColors.strokeHi),
        ),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 200),
          transitionBuilder: (c, a) => ScaleTransition(scale: a, child: c),
          child: Icon(icon, key: ValueKey(icon), size: size * 0.5, color: fg),
        ),
      ),
    );
  }
}

/// Animated concentric-ripple logo mark (brand cyan only).
class LogoMark extends StatefulWidget {
  const LogoMark({super.key, this.size = 44});
  final double size;

  @override
  State<LogoMark> createState() => _LogoMarkState();
}

class _LogoMarkState extends State<LogoMark> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 3))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => CustomPaint(painter: _LogoPainter(_c.value)),
      ),
    );
  }
}

class _LogoPainter extends CustomPainter {
  _LogoPainter(this.t);
  final double t;

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    final rr = RRect.fromRectAndRadius(Offset.zero & size, Radius.circular(r * 0.55));
    canvas.drawRRect(rr, Paint()..color = AppColors.surfaceHi);
    canvas.save();
    canvas.clipRRect(rr);
    for (int k = 0; k < 3; k++) {
      final p = (t + k / 3) % 1.0;
      canvas.drawCircle(
        c,
        r * (0.15 + 0.85 * p),
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = math.max(1.4, r * 0.07)
          ..color = AppColors.cyan.withValues(alpha: (1 - p) * 0.95),
      );
    }
    canvas.restore();
    canvas.drawCircle(c, r * 0.14, Paint()..color = AppColors.amber);
    canvas.drawRRect(
      rr.deflate(0.5),
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1
        ..color = AppColors.strokeHi,
    );
  }

  @override
  bool shouldRepaint(covariant _LogoPainter old) => old.t != t;
}

/// Quiet lab background: ink navy with a faint measurement grid.
class LabBackground extends StatelessWidget {
  const LabBackground({super.key});

  @override
  Widget build(BuildContext context) {
    return const RepaintBoundary(
      child: CustomPaint(painter: _GridPainter(), size: Size.infinite),
    );
  }
}

class _GridPainter extends CustomPainter {
  const _GridPainter();

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [AppColors.bgTop, AppColors.bg],
        ).createShader(rect),
    );
    final minor = Paint()
      ..color = const Color(0x0AFFFFFF)
      ..strokeWidth = 1;
    final major = Paint()
      ..color = const Color(0x12FFFFFF)
      ..strokeWidth = 1;
    const step = 24.0;
    int k = 0;
    for (double x = 0; x < size.width; x += step, k++) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), k % 5 == 0 ? major : minor);
    }
    k = 0;
    for (double y = 0; y < size.height; y += step, k++) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), k % 5 == 0 ? major : minor);
    }
    // soft brand glow at the top
    final glow = Rect.fromCircle(center: Offset(size.width * 0.5, -size.height * 0.1), radius: size.longestSide * 0.6);
    canvas.drawRect(
      rect,
      Paint()
        ..shader = RadialGradient(
          colors: [AppColors.cyan.withValues(alpha: 0.08), AppColors.cyan.withValues(alpha: 0)],
        ).createShader(glow),
    );
  }

  @override
  bool shouldRepaint(covariant _GridPainter old) => false;
}

/// Small uppercase-style section label.
class SectionLabel extends StatelessWidget {
  const SectionLabel(this.text, {super.key});
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w700,
        color: AppColors.textDim,
        letterSpacing: 0.3,
      ),
    );
  }
}
