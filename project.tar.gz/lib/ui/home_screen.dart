import 'package:flutter/material.dart';

import '../credits.dart';
import '../sim_controller.dart';
import '../theme.dart';
import 'about_sheet.dart';
import 'control_panel.dart';
import 'sim_canvas.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final SimController c = SimController();

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          const LabBackground(),
          SafeArea(
            child: LayoutBuilder(builder: (context, box) {
              final wide = box.maxWidth >= 860 && box.maxWidth > box.maxHeight;
              return Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    StaggerIn(index: 0, child: _TopBar(c: c, compact: !wide)),
                    const SizedBox(height: 12),
                    Expanded(
                      child: wide
                          ? Row(
                              children: [
                                Expanded(child: StaggerIn(index: 1, child: _TankFrame(c: c))),
                                const SizedBox(width: 12),
                                SizedBox(
                                  width: 380,
                                  child: StaggerIn(index: 2, child: ControlPanel(c: c)),
                                ),
                              ],
                            )
                          : Column(
                              children: [
                                StaggerIn(
                                  index: 1,
                                  child: ConstrainedBox(
                                    constraints: BoxConstraints(maxHeight: box.maxHeight * 0.55),
                                    child: AspectRatio(aspectRatio: 1, child: _TankFrame(c: c)),
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Expanded(
                                  child: StaggerIn(index: 2, child: ControlPanel(c: c)),
                                ),
                              ],
                            ),
                    ),
                  ],
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _TankFrame extends StatelessWidget {
  const _TankFrame({required this.c});
  final SimController c;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final side = box.maxWidth < box.maxHeight ? box.maxWidth : box.maxHeight;
      return Center(
        child: Container(
          width: side,
          height: side,
          padding: const EdgeInsets.all(1.5),
          decoration: BoxDecoration(
            color: AppColors.strokeHi,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(color: AppColors.cyan.withValues(alpha: 0.10), blurRadius: 40, spreadRadius: -6),
              const BoxShadow(color: Color(0x88000000), blurRadius: 30, offset: Offset(0, 14)),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(18.5),
            child: SimCanvas(c: c),
          ),
        ),
      );
    });
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.c, required this.compact});
  final SimController c;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final b = compact ? 36.0 : 40.0;
    return Panel(
      radius: 16,
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: compact ? 8 : 10),
      child: AnimatedBuilder(
        animation: c,
        builder: (context, _) => Row(
          children: [
            LogoMark(size: compact ? 36 : 42),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'RIPPLE TANK',
                    style: TextStyle(
                      fontSize: compact ? 15 : 18,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.5,
                      color: AppColors.text,
                    ),
                  ),
                  Text(
                    compact ? Credits.appNameAr : '${Credits.appNameAr}  ·  ${Credits.developer}',
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: compact ? 11 : 12.5, color: AppColors.textDim),
                  ),
                ],
              ),
            ),
            _ViewToggle(c: c, compact: compact),
            const SizedBox(width: 8),
            IconBtn(
              icon: c.paused ? Icons.play_arrow_rounded : Icons.pause_rounded,
              active: c.paused,
              tooltip: c.paused ? 'تشغيل' : 'إيقاف مؤقت',
              size: b,
              onTap: c.togglePause,
            ),
            const SizedBox(width: 8),
            if (!compact) ...[
              IconBtn(
                icon: Icons.restart_alt_rounded,
                tooltip: 'إعادة التجربة',
                size: b,
                onTap: () => c.presetIndex >= 0 ? c.loadPreset(c.presetIndex) : c.clearWaves(),
              ),
              const SizedBox(width: 8),
            ],
            IconBtn(
              icon: Icons.info_outline_rounded,
              tooltip: 'حول التطبيق',
              size: b,
              onTap: () => showAbout(context),
            ),
          ],
        ),
      ),
    );
  }
}

class _ViewToggle extends StatelessWidget {
  const _ViewToggle({required this.c, required this.compact});
  final SimController c;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final w = compact ? 42.0 : 50.0;
    final h = compact ? 30.0 : 34.0;
    return Pressable(
      onTap: () => c.setView3D(!c.view3D),
      tooltip: '2D / 3D',
      child: Container(
        width: w * 2 + 8,
        height: h + 8,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: AppColors.bg,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.strokeHi),
        ),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Stack(
            children: [
              AnimatedPositioned(
                duration: const Duration(milliseconds: 320),
                curve: Curves.easeOutCubic,
                left: c.view3D ? w : 0,
                top: 0,
                width: w,
                height: h,
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.cyan,
                    borderRadius: BorderRadius.circular(9),
                  ),
                ),
              ),
              Row(
                children: [
                  for (final label in const ['2D', '3D'])
                    SizedBox(
                      width: w,
                      height: h,
                      child: Center(
                        child: AnimatedDefaultTextStyle(
                          duration: const Duration(milliseconds: 220),
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: compact ? 13 : 14,
                            color: (label == '3D') == c.view3D
                                ? AppColors.onCyan
                                : AppColors.textDim,
                          ),
                          child: Text(label),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
