import 'package:flutter/material.dart';

import '../credits.dart';
import '../sim_controller.dart';
import '../theme.dart';
import 'about_sheet.dart';
import 'control_panel.dart';
import 'sim_canvas.dart';
import 'widgets.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final SimController c = SimController();

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          const AuroraBackground(),
          SafeArea(
            child: LayoutBuilder(builder: (context, box) {
              final wide = box.maxWidth >= 860 && box.maxWidth > box.maxHeight;
              return Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  children: [
                    StaggerIn(index: 0, child: _TopBar(c: c, compact: !wide)),
                    const SizedBox(height: 12),
                    Expanded(
                      child: wide
                          ? Row(
                              children: [
                                Expanded(child: StaggerIn(index: 1, child: _TankFrame(c: c))),
                                const SizedBox(width: 12),
                                SizedBox(
                                  width: 380,
                                  child: StaggerIn(index: 2, child: ControlPanel(c: c)),
                                ),
                              ],
                            )
                          : Column(
                              children: [
                                StaggerIn(
                                  index: 1,
                                  child: ConstrainedBox(
                                    constraints: BoxConstraints(
                                      maxHeight: box.maxHeight * 0.55,
                                    ),
                                    child: AspectRatio(aspectRatio: 1, child: _TankFrame(c: c)),
                                  ),
                                ),
                                const SizedBox(height: 12),
                                Expanded(
                                  child: StaggerIn(
                                    index: 2,
                                    child: ControlPanel(c: c, compact: true),
                                  ),
                                ),
                              ],
                            ),
                    ),
                  ],
                ),
              );
            }),
          ),
        ],
      ),
    );
  }
}

class _TankFrame extends StatelessWidget {
  const _TankFrame({required this.c});
  final SimController c;

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final side = box.maxWidth < box.maxHeight ? box.maxWidth : box.maxHeight;
      return Center(
        child: Container(
          width: side,
          height: side,
          padding: const EdgeInsets.all(2),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(26),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [Color(0x9936E2F5), Color(0x338B5CF6), Color(0x99F472B6)],
            ),
            boxShadow: [
              BoxShadow(color: AppColors.cyan.withValues(alpha: 0.18), blurRadius: 40, spreadRadius: -8),
              BoxShadow(color: AppColors.violet.withValues(alpha: 0.15), blurRadius: 60, spreadRadius: -10),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: SimCanvas(c: c),
          ),
        ),
      );
    });
  }
}

class _TopBar extends StatelessWidget {
  const _TopBar({required this.c, required this.compact});
  final SimController c;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      radius: 20,
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: compact ? 8 : 10),
      child: AnimatedBuilder(
        animation: c,
        builder: (context, _) => Row(
          children: [
            LogoMark(size: compact ? 38 : 44),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  GradientText(
                    'RIPPLE TANK',
                    style: TextStyle(
                      fontSize: compact ? 16 : 19,
                      fontWeight: FontWeight.w900,
                      letterSpacing: 2.5,
                    ),
                  ),
                  Text(
                    compact ? Credits.appNameAr : '${Credits.appNameAr}  •  ${Credits.developer}',
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: compact ? 11 : 12.5, color: AppColors.textDim),
                  ),
                ],
              ),
            ),
            _ViewToggle(c: c, compact: compact),
            const SizedBox(width: 8),
            GlassIconButton(
              icon: c.paused ? Icons.play_arrow_rounded : Icons.pause_rounded,
              active: c.paused,
              tooltip: c.paused ? 'تشغيل' : 'إيقاف مؤقت',
              size: compact ? 38 : 42,
              onTap: c.togglePause,
            ),
            const SizedBox(width: 8),
            if (!compact) ...[
              GlassIconButton(
                icon: Icons.restart_alt_rounded,
                tooltip: 'إعادة التجربة',
                onTap: () => c.presetIndex >= 0 ? c.loadPreset(c.presetIndex) : c.clearWaves(),
              ),
              const SizedBox(width: 8),
            ],
            GlassIconButton(
              icon: Icons.info_outline_rounded,
              tooltip: 'حول التطبيق',
              size: compact ? 38 : 42,
              onTap: () => showAbout(context),
            ),
          ],
        ),
      ),
    );
  }
}

class _ViewToggle extends StatelessWidget {
  const _ViewToggle({required this.c, required this.compact});
  final SimController c;
  final bool compact;

  @override
  Widget build(BuildContext context) {
    final w = compact ? 44.0 : 52.0;
    final h = compact ? 34.0 : 38.0;
    return Pressable(
      onTap: () => c.setView3D(!c.view3D),
      tooltip: '2D / 3D',
      child: Container(
        width: w * 2 + 8,
        height: h + 8,
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(
          color: Colors.black.withValues(alpha: 0.3),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: Colors.white.withValues(alpha: 0.1)),
        ),
        child: Directionality(
          textDirection: TextDirection.ltr,
          child: Stack(
            children: [
              AnimatedPositioned(
                duration: const Duration(milliseconds: 380),
                curve: Curves.easeOutBack,
                left: c.view3D ? w : 0,
                top: 0,
                width: w,
                height: h,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: AppColors.brand,
                    borderRadius: BorderRadius.circular(11),
                  ),
                ),
              ),
              Row(
                children: [
                  for (final label in const ['2D', '3D'])
                    SizedBox(
                      width: w,
                      height: h,
                      child: Center(
                        child: Text(
                          label,
                          style: TextStyle(
                            fontWeight: FontWeight.w900,
                            fontSize: compact ? 13 : 14,
                            color: (label == '3D') == c.view3D
                                ? Colors.white
                                : AppColors.textDim,
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
