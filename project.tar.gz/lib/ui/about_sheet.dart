import 'package:flutter/material.dart';

import '../credits.dart';
import '../theme.dart';
import 'widgets.dart';

void showAbout(BuildContext context) {
  showGeneralDialog(
    context: context,
    barrierDismissible: true,
    barrierLabel: 'about',
    barrierColor: Colors.black.withValues(alpha: 0.7),
    transitionDuration: const Duration(milliseconds: 450),
    pageBuilder: (context, a, b) => const _AboutDialog(),
    transitionBuilder: (context, a, b, child) {
      final c = CurvedAnimation(parent: a, curve: Curves.easeOutBack);
      return FadeTransition(
        opacity: a,
        child: ScaleTransition(scale: Tween(begin: 0.85, end: 1.0).animate(c), child: child),
      );
    },
  );
}

class _AboutDialog extends StatelessWidget {
  const _AboutDialog();

  @override
  Widget build(BuildContext context) {
    final items = <Widget>[
      const Center(child: LogoMark(size: 78)),
      const SizedBox(height: 12),
      const Center(
        child: Text(Credits.appName,
            style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1, color: AppColors.text)),
      ),
      const Center(
        child: Text('${Credits.appNameAr} • v${Credits.version}',
            style: TextStyle(color: AppColors.textDim, fontSize: 13)),
      ),
      const SizedBox(height: 18),
      _card(
        Column(
          children: [
            const Text('برمجة وتطوير', style: TextStyle(color: AppColors.textDim, fontSize: 12.5)),
            const SizedBox(height: 4),
            const Text(Credits.developer,
                style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: AppColors.cyan)),
            const Text(Credits.developerEn,
                style: TextStyle(color: AppColors.textDim, fontSize: 12, letterSpacing: 1)),
            const SizedBox(height: 12),
            _row(Icons.security_rounded, 'التخصص', Credits.major),
            _row(Icons.school_rounded, 'الجامعة', Credits.university),
            _row(Icons.person_rounded, 'أستاذ المادة', Credits.supervisor),
          ],
        ),
      ),
      const SizedBox(height: 12),
      _card(
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('الظواهر المدعومة', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            SizedBox(height: 8),
            _Bullet('الانعكاس', 'ارتداد الأمواج عن الجدران والأسطح الصلبة'),
            _Bullet('الحيود', 'انحناء الأمواج خلال الشقوق المفردة والمزدوجة'),
            _Bullet('التشتت', 'إعادة توزيع اتجاه الموجة عند العوائق الخشنة'),
            _Bullet('الانكسار والامتصاص', 'تباطؤ الموجة داخل العدسات والمنشور وتضاؤل طاقتها'),
          ],
        ),
      ),
      const SizedBox(height: 12),
      _card(
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('المحرك الفيزيائي', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14)),
            SizedBox(height: 8),
            _Bullet('FDTD', 'حل معادلة الموجة على شبكة 180×180 بمؤثر لابلاس ثنائي الأبعاد'),
            _Bullet('Typed Data', 'ذاكرة Float32List / Uint8List لأداء 60 إطاراً بالثانية'),
            _Bullet('3D Mesh', 'شبكة ارتفاعات حقيقية عبر ui.Vertices مع كاميرا Pitch & Yaw'),
            _Bullet('تفاعل', 'سحب وإفلات في 2D و3D، تردد مستقل لكل مصدر، وتغيير حجم العدسات والشقوق والحواجز'),
            _Bullet('مجسات', 'راسم إشارة حي يعرض السعة القصوى A والتردد f'),
            _Bullet('Dart فقط', 'بدون مكتبات خارجية: dart:async • dart:math • dart:typed_data • dart:ui'),
          ],
        ),
      ),
    ];

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(18),
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 460, maxHeight: 720),
          child: Material(
            type: MaterialType.transparency,
            child: Panel(
              padding: const EdgeInsets.fromLTRB(18, 18, 18, 12),
              child: Column(
                children: [
                  Expanded(
                    child: ListView(
                      padding: EdgeInsets.zero,
                      children: [
                        for (int i = 0; i < items.length; i++)
                          StaggerIn(index: i, child: items[i]),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Pressable(
                    onTap: () => Navigator.of(context).pop(),
                    child: Container(
                      height: 44,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: AppColors.cyan,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text('رجوع',
                          style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.onCyan)),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  static Widget _card(Widget child) => Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: AppColors.surfaceHi,
          border: Border.all(color: AppColors.stroke),
        ),
        child: child,
      );

  static Widget _row(IconData icon, String label, String value) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 4),
        child: Row(
          children: [
            Icon(icon, size: 17, color: AppColors.cyan),
            const SizedBox(width: 8),
            Text(label, style: const TextStyle(color: AppColors.textDim, fontSize: 13)),
            const Spacer(),
            Text(value, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5)),
          ],
        ),
      );
}

class _Bullet extends StatelessWidget {
  const _Bullet(this.title, this.text);
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 6),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 6),
            width: 6,
            height: 6,
            decoration: const BoxDecoration(shape: BoxShape.circle, color: AppColors.cyan),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text.rich(
              TextSpan(children: [
                TextSpan(text: '$title: ', style: const TextStyle(fontWeight: FontWeight.w800)),
                TextSpan(text: text, style: const TextStyle(color: AppColors.textDim)),
              ]),
              style: const TextStyle(fontSize: 12.5, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}
