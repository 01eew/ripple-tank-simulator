import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../engine/sim_objects.dart';
import '../engine/wave_engine.dart';
import '../render/field_2d.dart';
import '../render/field_3d.dart';
import '../sim_controller.dart';
import '../theme.dart';
import 'widgets.dart';

/// The interactive tank: runs the simulation loop, renders 2D/3D,
/// handles drag & drop, and shows floating probe cards.
class SimCanvas extends StatefulWidget {
  const SimCanvas({super.key, required this.c});
  final SimController c;

  @override
  State<SimCanvas> createState() => _SimCanvasState();
}

class _SimCanvasState extends State<SimCanvas> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  final Field2DRenderer _r2 = Field2DRenderer();
  final Mesh3D _mesh = Mesh3D();

  SimObject? _drag;
  Offset _grab = Offset.zero;
  bool _painting = false;
  Offset? _lastPaint;
  double _zoomStart = 1;
  bool _showHint = true;

  SimController get c => widget.c;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((_) {
      c.tick();
      if (!c.view3D) _r2.update(c);
    })
      ..start();
    Future.delayed(const Duration(seconds: 7), () {
      if (mounted) setState(() => _showHint = false);
    });
  }

  @override
  void dispose() {
    _ticker.dispose();
    _r2.dispose();
    super.dispose();
  }

  Offset _toGrid(Offset local, double side) =>
      local / (side / WaveEngine.n) - const Offset(0.5, 0.5);

  Offset _toScreen(Offset g, double side) =>
      (g + const Offset(0.5, 0.5)) * (side / WaveEngine.n);

  double _tol(double side) => math.max(4.0, 22 / (side / WaveEngine.n));

  // ------------------------------------------------------------- gestures

  void _onStart(ScaleStartDetails d, double side) {
    _zoomStart = c.zoom;
    if (c.view3D) return;
    final g = _toGrid(d.localFocalPoint, side);
    final hit = c.hitTest(g, _tol(side));
    if (hit != null) {
      _drag = hit;
      _grab = g - hit.pos;
      c.select(hit);
    } else {
      _painting = true;
      _lastPaint = g;
      c.poke(g);
    }
  }

  void _onUpdate(ScaleUpdateDetails d, double side) {
    if (c.view3D) {
      if (d.pointerCount >= 2) {
        c.setZoom(_zoomStart * d.scale);
      } else {
        c.rotateCamera(d.focalPointDelta.dx * 0.008, d.focalPointDelta.dy * 0.006);
      }
      return;
    }
    final g = _toGrid(d.localFocalPoint, side);
    if (_drag != null) {
      c.moveObject(_drag!, g - _grab);
    } else if (_painting) {
      if (_lastPaint == null || (g - _lastPaint!).distance >= 3) {
        c.poke(g, amp: 1.1);
        _lastPaint = g;
      }
    }
  }

  void _onEnd(ScaleEndDetails d) {
    _drag = null;
    _painting = false;
    _lastPaint = null;
  }

  void _onTap(TapUpDetails d, double side) {
    if (c.view3D) return;
    final g = _toGrid(d.localPosition, side);
    final hit = c.hitTest(g, _tol(side));
    if (hit != null) {
      c.select(hit);
    } else {
      c.select(null);
      c.poke(g, amp: 2.0);
    }
  }

  // ----------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final side = math.min(box.maxWidth, box.maxHeight);
      return Center(
        child: SizedBox(
          width: side,
          height: side,
          child: AnimatedBuilder(
            animation: c,
            builder: (context, _) => Stack(
              clipBehavior: Clip.hardEdge,
              children: [
                Positioned.fill(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onScaleStart: (d) => _onStart(d, side),
                    onScaleUpdate: (d) => _onUpdate(d, side),
                    onScaleEnd: _onEnd,
                    onTapUp: (d) => _onTap(d, side),
                    child: MouseRegion(
                      cursor: c.view3D ? SystemMouseCursors.grab : SystemMouseCursors.precise,
                      child: RepaintBoundary(
                        child: AnimatedSwitcher(
                          duration: const Duration(milliseconds: 450),
                          child: c.view3D
                              ? CustomPaint(
                                  key: const ValueKey('3d'),
                                  size: Size.square(side),
                                  painter: Field3DPainter(c, _mesh),
                                )
                              : CustomPaint(
                                  key: const ValueKey('2d'),
                                  size: Size.square(side),
                                  painter: Field2DPainter(c, _r2),
                                ),
                        ),
                      ),
                    ),
                  ),
                ),
                // probe cards
                Positioned.fill(
                  child: IgnorePointer(
                    child: ValueListenableBuilder<int>(
                      valueListenable: c.frame,
                      builder: (context, _, __) => _probeLayer(side),
                    ),
                  ),
                ),
                // hint
                Positioned(
                  top: 10,
                  left: 10,
                  right: 10,
                  child: IgnorePointer(
                    child: AnimatedOpacity(
                      opacity: _showHint ? 1 : 0,
                      duration: const Duration(milliseconds: 600),
                      child: Center(
                        child: _Chip(
                          icon: c.view3D ? Icons.threed_rotation : Icons.touch_app_rounded,
                          text: c.view3D
                              ? 'اسحب لتدوير الكاميرا • قرّب بإصبعين للتكبير'
                              : 'اسحب الأجسام لتحريكها • المس الماء لإحداث موجة',
                        ),
                      ),
                    ),
                  ),
                ),
                // selected object actions
                Positioned(
                  bottom: 12,
                  left: 0,
                  right: 0,
                  child: Center(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 300),
                      transitionBuilder: (child, a) => SlideTransition(
                        position: Tween(begin: const Offset(0, 0.6), end: Offset.zero)
                            .animate(CurvedAnimation(parent: a, curve: Curves.easeOutBack)),
                        child: FadeTransition(opacity: a, child: child),
                      ),
                      child: (c.selected != null && !c.view3D)
                          ? _SelectionBar(key: ValueKey(c.selected!.id), c: c)
                          : const SizedBox.shrink(),
                    ),
                  ),
                ),
                if (c.paused)
                  const Positioned(
                    top: 12,
                    right: 12,
                    child: IgnorePointer(
                      child: _Chip(icon: Icons.pause_rounded, text: 'متوقف مؤقتاً'),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    });
  }

  Widget _probeLayer(double side) {
    final probes = c.objects.where((o) => o.kind == ObjKind.probe).toList();
    if (probes.isEmpty) return const SizedBox.shrink();
    const w = 150.0, h = 104.0;
    final children = <Widget>[];
    final placed = <Rect>[];
    for (int k = 0; k < probes.length; k++) {
      final o = probes[k];
      final data = c.probes[o.id];
      if (data == null) continue;
      final no = c.probeNumber(o);
      Offset pos;
      if (c.view3D) {
        pos = Offset(10, 10 + k * (h + 8));
      } else {
        final p = _toScreen(o.pos, side);
        double x = p.dx + 16, y = p.dy - h - 10;
        if (x + w > side - 6) x = p.dx - w - 16;
        if (y < 6) y = p.dy + 16;
        x = x.clamp(6.0, math.max(6.0, side - w - 6));
        y = y.clamp(6.0, math.max(6.0, side - h - 6));
        // avoid overlapping other probe cards
        for (int guard = 0; guard < 6; guard++) {
          final r = Rect.fromLTWH(x, y, w, h);
          final hitRect = placed.where((q) => q.overlaps(r.inflate(3))).toList();
          if (hitRect.isEmpty) break;
          final q = hitRect.first;
          y = (q.bottom + 8 + h <= side - 6) ? q.bottom + 8 : q.top - h - 8;
          y = y.clamp(6.0, math.max(6.0, side - h - 6));
        }
        pos = Offset(x, y);
      }
      placed.add(Rect.fromLTWH(pos.dx, pos.dy, w, h));
      children.add(Positioned(
        left: pos.dx,
        top: pos.dy,
        width: w,
        height: h,
        child: _ProbeCard(number: no, data: data, frame: c.frame.value),
      ));
    }
    return Stack(children: children);
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: 0.45),
        borderRadius: BorderRadius.circular(30),
        border: Border.all(color: Colors.white.withValues(alpha: 0.12)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: AppColors.cyan),
          const SizedBox(width: 6),
          Flexible(
            child: Text(text,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, color: AppColors.text)),
          ),
        ],
      ),
    );
  }
}

class _SelectionBar extends StatelessWidget {
  const _SelectionBar({super.key, required this.c});
  final SimController c;

  @override
  Widget build(BuildContext context) {
    final o = c.selected!;
    return GlassCard(
      radius: 30,
      padding: const EdgeInsets.fromLTRB(8, 6, 14, 6),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: const BoxDecoration(shape: BoxShape.circle, gradient: AppColors.brand),
            child: Icon(o.kind.icon, size: 18, color: Colors.white),
          ),
          const SizedBox(width: 8),
          Text(o.kind.arName, style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(width: 10),
          if (o.kind.rotatable)
            GlassIconButton(
              icon: Icons.rotate_90_degrees_ccw,
              size: 34,
              tooltip: 'تدوير 90°',
              onTap: c.rotateSelected,
            ),
          const SizedBox(width: 6),
          GlassIconButton(
            icon: Icons.delete_outline_rounded,
            size: 34,
            tooltip: 'حذف',
            onTap: c.deleteSelected,
          ),
          const SizedBox(width: 6),
          GlassIconButton(
            icon: Icons.close_rounded,
            size: 34,
            tooltip: 'إلغاء التحديد',
            onTap: () => c.select(null),
          ),
        ],
      ),
    );
  }
}

class _ProbeCard extends StatelessWidget {
  const _ProbeCard({required this.number, required this.data, required this.frame});
  final int number;
  final ProbeData data;
  final int frame;

  @override
  Widget build(BuildContext context) {
    final color = probeColor(number);
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 7, 10, 7),
      decoration: BoxDecoration(
        color: const Color(0xCC071226),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withValues(alpha: 0.55)),
        boxShadow: [BoxShadow(color: color.withValues(alpha: 0.18), blurRadius: 14)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              ),
              const SizedBox(width: 6),
              Text('مجس $number',
                  style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: color)),
              const Spacer(),
              const Text('OSC', style: TextStyle(fontSize: 9, color: AppColors.textDim, letterSpacing: 1)),
            ],
          ),
          const SizedBox(height: 4),
          Expanded(
            child: CustomPaint(painter: _ScopePainter(data, color, frame)),
          ),
          const SizedBox(height: 4),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              children: [
                Text('A=${data.amplitude.toStringAsFixed(3)}',
                    style: const TextStyle(fontSize: 10.5, fontFamily: 'monospace', color: AppColors.text)),
                const Spacer(),
                Text(
                  data.frequency > 0 ? 'f=${data.frequency.toStringAsFixed(2)}Hz' : 'f=—',
                  style: const TextStyle(fontSize: 10.5, fontFamily: 'monospace', color: AppColors.text),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ScopePainter extends CustomPainter {
  _ScopePainter(this.d, this.color, this.frame);
  final ProbeData d;
  final Color color;
  final int frame;

  @override
  void paint(Canvas canvas, Size size) {
    final mid = size.height / 2;
    final grid = Paint()
      ..color = Colors.white.withValues(alpha: 0.08)
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, mid), Offset(size.width, mid), grid);
    for (int k = 1; k < 4; k++) {
      final x = size.width * k / 4;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    if (d.count < 2) return;
    final scale = d.amplitude > 1e-6 ? (mid - 2) / d.amplitude : 0.0;
    final path = Path();
    for (int k = 0; k < d.count; k++) {
      final x = size.width * k / (ProbeData.length - 1) +
          size.width * (ProbeData.length - d.count) / (ProbeData.length - 1);
      final y = mid - d.at(k) * scale;
      if (k == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 3
        ..color = color.withValues(alpha: 0.3)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 2),
    );
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = color,
    );
  }

  @override
  bool shouldRepaint(covariant _ScopePainter old) => true;
}
