import 'dart:math' as math;

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';

import '../engine/sim_objects.dart';
import '../engine/wave_engine.dart';
import '../render/field_2d.dart';
import '../render/field_3d.dart';
import '../sim_controller.dart';
import '../theme.dart';
import 'widgets.dart';

/// The interactive tank: runs the simulation loop, renders 2D/3D,
/// handles drag & drop (in both 2D and 3D), and shows floating probe cards.
class SimCanvas extends StatefulWidget {
  const SimCanvas({super.key, required this.c});
  final SimController c;

  @override
  State<SimCanvas> createState() => _SimCanvasState();
}

class _SimCanvasState extends State<SimCanvas> with SingleTickerProviderStateMixin {
  late final Ticker _ticker;
  final Field2DRenderer _r2 = Field2DRenderer();
  final Mesh3D _mesh = Mesh3D();

  SimObject? _drag;
  Offset _grab = Offset.zero;
  bool _painting = false;
  Offset? _lastPaint;
  double _zoomStart = 1;
  bool _showHint = true;
  Offset? _downPos; // exact pointer-down point (scale start can lag behind)

  SimController get c => widget.c;

  @override
  void initState() {
    super.initState();
    _ticker = createTicker((_) {
      c.tick();
      if (!c.view3D) _r2.update(c);
    })
      ..start();
    Future.delayed(const Duration(seconds: 7), () {
      if (mounted) setState(() => _showHint = false);
    });
  }

  @override
  void dispose() {
    _ticker.dispose();
    _r2.dispose();
    super.dispose();
  }

  Offset _toScreen(Offset g, double side) =>
      (g + const Offset(0.5, 0.5)) * (side / WaveEngine.n);

  /// Screen point → grid coordinates for the current view (2D or 3D).
  Offset? _toGrid(Offset local, double side) {
    if (c.view3D) return _mesh.screenToGrid(local, Size.square(side), c);
    return local / (side / WaveEngine.n) - const Offset(0.5, 0.5);
  }

  double _tol(double side) =>
      c.view3D ? 7.0 : math.max(4.0, 22 / (side / WaveEngine.n));

  // ------------------------------------------------------------- gestures

  void _onStart(ScaleStartDetails d, double side) {
    _zoomStart = c.zoom;
    _drag = null;
    _painting = false;
    if (d.pointerCount >= 2) return;
    final g = _toGrid(_downPos ?? d.localFocalPoint, side);
    if (g == null) return;
    final hit = c.hitTest(g, _tol(side));
    if (hit != null) {
      _drag = hit;
      _grab = g - hit.pos;
      c.select(hit);
    } else if (!c.view3D) {
      _painting = true;
      _lastPaint = g;
      c.poke(g);
    }
  }

  void _onUpdate(ScaleUpdateDetails d, double side) {
    if (c.view3D && d.pointerCount >= 2) {
      _drag = null;
      c.setZoom(_zoomStart * d.scale);
      return;
    }
    if (_drag != null) {
      final g = _toGrid(d.localFocalPoint, side);
      if (g != null) c.moveObject(_drag!, g - _grab);
      return;
    }
    if (c.view3D) {
      c.rotateCamera(d.focalPointDelta.dx * 0.008, d.focalPointDelta.dy * 0.006);
      return;
    }
    if (_painting) {
      final g = _toGrid(d.localFocalPoint, side);
      if (g == null) return;
      if (_lastPaint == null || (g - _lastPaint!).distance >= 3) {
        c.poke(g, amp: 1.1);
        _lastPaint = g;
      }
    }
  }

  void _onEnd(ScaleEndDetails d) {
    _drag = null;
    _painting = false;
    _lastPaint = null;
  }

  void _onTap(TapUpDetails d, double side) {
    final g = _toGrid(d.localPosition, side);
    if (g == null) return;
    final hit = c.hitTest(g, _tol(side));
    if (hit != null) {
      c.select(hit);
    } else {
      c.select(null);
      c.poke(g, amp: 2.0);
    }
  }

  void _onScroll(PointerSignalEvent e) {
    if (e is PointerScrollEvent && c.view3D) {
      c.setZoom(c.zoom * (1 - e.scrollDelta.dy * 0.0012));
    }
  }

  // ----------------------------------------------------------------- build

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, box) {
      final side = math.min(box.maxWidth, box.maxHeight);
      return Center(
        child: SizedBox(
          width: side,
          height: side,
          child: AnimatedBuilder(
            animation: c,
            builder: (context, _) => Stack(
              clipBehavior: Clip.hardEdge,
              children: [
                Positioned.fill(
                  child: Listener(
                    onPointerSignal: _onScroll,
                    onPointerDown: (e) => _downPos = e.localPosition,
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onScaleStart: (d) => _onStart(d, side),
                      onScaleUpdate: (d) => _onUpdate(d, side),
                      onScaleEnd: _onEnd,
                      onTapUp: (d) => _onTap(d, side),
                      child: MouseRegion(
                        cursor: c.view3D ? SystemMouseCursors.grab : SystemMouseCursors.precise,
                        child: RepaintBoundary(
                          child: AnimatedSwitcher(
                            duration: const Duration(milliseconds: 400),
                            child: c.view3D
                                ? CustomPaint(
                                    key: const ValueKey('3d'),
                                    size: Size.square(side),
                                    painter: Field3DPainter(c, _mesh),
                                  )
                                : CustomPaint(
                                    key: const ValueKey('2d'),
                                    size: Size.square(side),
                                    painter: Field2DPainter(c, _r2),
                                  ),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // probe cards
                Positioned.fill(
                  child: IgnorePointer(
                    child: ValueListenableBuilder<int>(
                      valueListenable: c.frame,
                      builder: (context, _, __) => _probeLayer(side),
                    ),
                  ),
                ),
                // hint
                Positioned(
                  top: 10,
                  left: 10,
                  right: 10,
                  child: IgnorePointer(
                    child: AnimatedOpacity(
                      opacity: _showHint ? 1 : 0,
                      duration: const Duration(milliseconds: 600),
                      child: Center(
                        child: _Chip(
                          icon: c.view3D ? Icons.threed_rotation : Icons.touch_app_rounded,
                          text: c.view3D
                              ? 'اسحب الجسم لتحريكه • اسحب الفراغ للتدوير • إصبعان للتكبير'
                              : 'اسحب الأجسام لتحريكها • المس الماء لإحداث موجة',
                        ),
                      ),
                    ),
                  ),
                ),
                // selected object editor
                Positioned(
                  bottom: 10,
                  left: 10,
                  right: 10,
                  child: Center(
                    child: AnimatedSwitcher(
                      duration: const Duration(milliseconds: 280),
                      transitionBuilder: (child, a) => SlideTransition(
                        position: Tween(begin: const Offset(0, 0.4), end: Offset.zero)
                            .animate(CurvedAnimation(parent: a, curve: Curves.easeOutCubic)),
                        child: FadeTransition(opacity: a, child: child),
                      ),
                      child: c.selected != null
                          ? _SelectionEditor(key: ValueKey(c.selected!.id), c: c)
                          : const SizedBox.shrink(),
                    ),
                  ),
                ),
                if (c.paused)
                  const Positioned(
                    top: 12,
                    right: 12,
                    child: IgnorePointer(
                      child: _Chip(icon: Icons.pause_rounded, text: 'متوقف مؤقتاً'),
                    ),
                  ),
              ],
            ),
          ),
        ),
      );
    });
  }

  Widget _probeLayer(double side) {
    final probes = c.objects.where((o) => o.kind == ObjKind.probe).toList();
    if (probes.isEmpty) return const SizedBox.shrink();
    final small = side < 460;
    final w = small ? 118.0 : 150.0, h = small ? 84.0 : 104.0;
    final children = <Widget>[];
    final placed = <Rect>[];
    for (int k = 0; k < probes.length; k++) {
      final o = probes[k];
      final data = c.probes[o.id];
      if (data == null) continue;
      final no = c.probeNumber(o);
      Offset pos;
      if (c.view3D) {
        pos = Offset(10, 10 + k * (h + 8));
      } else {
        final p = _toScreen(o.pos, side);
        double x = p.dx + 16, y = p.dy - h - 10;
        if (x + w > side - 6) x = p.dx - w - 16;
        if (y < 6) y = p.dy + 16;
        x = x.clamp(6.0, math.max(6.0, side - w - 6));
        y = y.clamp(6.0, math.max(6.0, side - h - 6));
        // avoid overlapping other probe cards
        for (int guard = 0; guard < 6; guard++) {
          final r = Rect.fromLTWH(x, y, w, h);
          final hitRect = placed.where((q) => q.overlaps(r.inflate(3))).toList();
          if (hitRect.isEmpty) break;
          final q = hitRect.first;
          y = (q.bottom + 8 + h <= side - 6) ? q.bottom + 8 : q.top - h - 8;
          y = y.clamp(6.0, math.max(6.0, side - h - 6));
        }
        pos = Offset(x, y);
      }
      placed.add(Rect.fromLTWH(pos.dx, pos.dy, w, h));
      children.add(Positioned(
        left: pos.dx,
        top: pos.dy,
        width: w,
        height: h,
        child: _ProbeCard(number: no, data: data, frame: c.frame.value, small: small),
      ));
    }
    return Stack(children: children);
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
      decoration: BoxDecoration(
        color: AppColors.bg.withValues(alpha: 0.82),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.strokeHi),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 15, color: AppColors.cyan),
          const SizedBox(width: 6),
          Flexible(
            child: Text(text,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12, color: AppColors.text)),
          ),
        ],
      ),
    );
  }
}

/// Floating editor for the selected object: rotate / delete, plus
/// a frequency slider (sources) and a size slider (resizable objects).
class _SelectionEditor extends StatelessWidget {
  const _SelectionEditor({super.key, required this.c});
  final SimController c;

  @override
  Widget build(BuildContext context) {
    final o = c.selected!;
    final kindColor = o.kind.isSource
        ? AppColors.amber
        : o.kind == ObjKind.probe
            ? probeColor(c.probeNumber(o))
            : AppColors.cyan;
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 380),
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 8, 10, 6),
        decoration: BoxDecoration(
          color: AppColors.surface.withValues(alpha: 0.96),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.strokeHi),
          boxShadow: const [BoxShadow(color: Color(0x88000000), blurRadius: 18)],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: kindColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(9),
                  ),
                  child: Icon(o.kind.icon, size: 17, color: kindColor),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(o.kind.arName,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 13.5)),
                ),
                if (o.kind.rotatable) ...[
                  IconBtn(
                    icon: Icons.rotate_90_degrees_ccw,
                    size: 32,
                    tooltip: 'تدوير 90°',
                    onTap: c.rotateSelected,
                  ),
                  const SizedBox(width: 6),
                ],
                IconBtn(
                  icon: Icons.delete_outline_rounded,
                  size: 32,
                  danger: true,
                  tooltip: 'حذف',
                  onTap: c.deleteSelected,
                ),
                const SizedBox(width: 6),
                IconBtn(
                  icon: Icons.close_rounded,
                  size: 32,
                  tooltip: 'إلغاء التحديد',
                  onTap: () => c.select(null),
                ),
              ],
            ),
            if (o.kind.isSource)
              _MiniSlider(
                label: 'تردد المصدر',
                value: o.freq,
                min: 0.8,
                max: 7,
                display: '${o.freq.toStringAsFixed(1)} Hz',
                color: AppColors.amber,
                onChanged: c.setSelectedFrequency,
              ),
            if (o.kind.resizable)
              _MiniSlider(
                label: o.kind.sizeLabel,
                value: o.scale,
                min: SimObject.minScale,
                max: SimObject.maxScale,
                display: '×${o.scale.toStringAsFixed(2)}',
                color: AppColors.cyan,
                onChanged: c.setSelectedScale,
              ),
          ],
        ),
      ),
    );
  }
}

class _MiniSlider extends StatelessWidget {
  const _MiniSlider({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.display,
    required this.color,
    required this.onChanged,
  });
  final String label;
  final double value, min, max;
  final String display;
  final Color color;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Row(
        children: [
          SizedBox(
            width: 92,
            child: Text(label,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 11.5, color: AppColors.textDim)),
          ),
          Expanded(
            child: SizedBox(
              height: 30,
              child: SliderTheme(
                data: SliderTheme.of(context).copyWith(
                  activeTrackColor: color,
                  thumbColor: color,
                  overlayColor: color.withValues(alpha: 0.15),
                ),
                child: Slider(
                  value: value.clamp(min, max),
                  min: min,
                  max: max,
                  onChanged: onChanged,
                ),
              ),
            ),
          ),
          SizedBox(
            width: 56,
            child: Directionality(
              textDirection: TextDirection.ltr,
              child: Text(display,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700, color: color)),
            ),
          ),
        ],
      ),
    );
  }
}

class _ProbeCard extends StatelessWidget {
  const _ProbeCard({required this.number, required this.data, required this.frame, this.small = false});
  final int number;
  final ProbeData data;
  final int frame;
  final bool small;

  @override
  Widget build(BuildContext context) {
    final color = probeColor(number);
    return Container(
      padding: const EdgeInsets.fromLTRB(10, 7, 10, 7),
      decoration: BoxDecoration(
        color: AppColors.bg.withValues(alpha: 0.88),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.strokeHi),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(color: color, shape: BoxShape.circle),
              ),
              const SizedBox(width: 6),
              Text('مجس $number',
                  style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800, color: AppColors.text)),
              const Spacer(),
              const Text('OSC', style: TextStyle(fontSize: 9, color: AppColors.textFaint, letterSpacing: 1)),
            ],
          ),
          const SizedBox(height: 4),
          Expanded(
            child: CustomPaint(painter: _ScopePainter(data, color, frame)),
          ),
          const SizedBox(height: 4),
          Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              children: [
                Text('A=${data.amplitude.toStringAsFixed(small ? 2 : 3)}',
                    style: TextStyle(fontSize: small ? 9.5 : 10.5, fontFamily: 'monospace', color: AppColors.text)),
                const Spacer(),
                Text(
                  data.frequency > 0 ? 'f=${data.frequency.toStringAsFixed(small ? 1 : 2)}Hz' : 'f=—',
                  style: TextStyle(fontSize: small ? 9.5 : 10.5, fontFamily: 'monospace', color: AppColors.text),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ScopePainter extends CustomPainter {
  _ScopePainter(this.d, this.color, this.frame);
  final ProbeData d;
  final Color color;
  final int frame;

  @override
  void paint(Canvas canvas, Size size) {
    final mid = size.height / 2;
    final grid = Paint()
      ..color = AppColors.stroke
      ..strokeWidth = 1;
    canvas.drawLine(Offset(0, mid), Offset(size.width, mid), grid);
    for (int k = 1; k < 4; k++) {
      final x = size.width * k / 4;
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    if (d.count < 2) return;
    final scale = d.amplitude > 1e-6 ? (mid - 2) / d.amplitude : 0.0;
    final path = Path();
    for (int k = 0; k < d.count; k++) {
      final x = size.width * k / (ProbeData.length - 1) +
          size.width * (ProbeData.length - d.count) / (ProbeData.length - 1);
      final y = mid - d.at(k) * scale;
      if (k == 0) {
        path.moveTo(x, y);
      } else {
        path.lineTo(x, y);
      }
    }
    canvas.drawPath(
      path,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.5
        ..color = color,
    );
  }

  @override
  bool shouldRepaint(covariant _ScopePainter old) => true;
}
