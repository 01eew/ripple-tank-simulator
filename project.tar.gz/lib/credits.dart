/// معلومات المطوّر — تظهر في شاشة البداية وشاشة "حول التطبيق".
class Credits {
  static const appName = 'Ripple Tank Simulator';
  static const appNameAr = 'محاكي حوض الأمواج التفاعلي';
  static const version = '1.0.0';
  static const developer = 'حسين خالد حميد';
  static const developerEn = 'Hussein Khalid Hameed';
  static const major = 'هندسة الأمن السيبراني';
  static const university = 'جامعة المعقل';
  static const supervisor = 'د. أحمد دنقل';
}
