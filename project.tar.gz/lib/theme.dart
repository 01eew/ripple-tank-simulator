import 'package:flutter/material.dart';

class AppColors {
  static const bg = Color(0xFF040915);
  static const bg2 = Color(0xFF0A1530);
  static const surface = Color(0xFF0E1A36);
  static const cyan = Color(0xFF36E2F5);
  static const blue = Color(0xFF3B82F6);
  static const violet = Color(0xFF8B5CF6);
  static const pink = Color(0xFFF472B6);
  static const amber = Color(0xFFFBBF24);
  static const text = Color(0xFFE8F1FF);
  static const textDim = Color(0xFF8EA3C7);
  static const stroke = Color(0x22FFFFFF);

  static const brand = LinearGradient(
    colors: [cyan, violet, pink],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
}

const probeColors = <Color>[
  Color(0xFFFFD166),
  Color(0xFFFF5FA2),
  Color(0xFF7CFFB2),
  Color(0xFFA78BFA),
  Color(0xFF60A5FA),
];

Color probeColor(int number) => probeColors[(number - 1) % probeColors.length];

ThemeData buildTheme() {
  final base = ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.cyan,
      secondary: AppColors.violet,
      surface: AppColors.surface,
    ),
    scaffoldBackgroundColor: AppColors.bg,
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(
      bodyColor: AppColors.text,
      displayColor: AppColors.text,
    ),
    sliderTheme: const SliderThemeData(
      trackHeight: 4,
      activeTrackColor: AppColors.cyan,
      inactiveTrackColor: Color(0x3336E2F5),
      thumbColor: Colors.white,
      overlayColor: Color(0x2236E2F5),
      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 8),
    ),
  );
}
