// Visual identity — "Signal Lab"
// One brand colour (Signal Cyan) on deep ink navy, plus a small set of
// *semantic* colours that always mean the same thing everywhere:
//   • Amber  = energy / wave sources
//   • Cyan   = brand, selection, glass media (lens, prism)
//   • Steel  = hard barriers (walls, slits, rough surface)
//   • Coral  = absorbing material, delete actions
//   • Probe colours = one fixed colour per measuring probe

import 'package:flutter/material.dart';

class AppColors {
  // surfaces
  static const bg = Color(0xFF070B14);
  static const bgTop = Color(0xFF0C1424);
  static const surface = Color(0xFF101827);
  static const surfaceHi = Color(0xFF162133);
  static const stroke = Color(0xFF1F2B40);
  static const strokeHi = Color(0xFF2B3A55);

  // text
  static const text = Color(0xFFE6EDF7);
  static const textDim = Color(0xFF8A97B0);
  static const textFaint = Color(0xFF5B6880);

  // brand
  static const cyan = Color(0xFF22D3EE);
  static const cyanDeep = Color(0xFF0891B2);
  static const onCyan = Color(0xFF04141A);

  // semantic
  static const amber = Color(0xFFFBBF24); // sources / energy
  static const steel = Color(0xFFC7D2E3); // walls & barriers
  static const coral = Color(0xFFFB7185); // absorber / delete
}

/// Fixed colours for probes 1, 2, 3 … (categorical, colour-blind friendly).
const probeColors = <Color>[
  Color(0xFFFBBF24), // amber
  Color(0xFF38BDF8), // sky
  Color(0xFF34D399), // mint
  Color(0xFFF472B6), // pink
  Color(0xFFA78BFA), // violet
];

Color probeColor(int number) => probeColors[(number - 1) % probeColors.length];

ThemeData buildTheme() {
  final base = ThemeData(
    brightness: Brightness.dark,
    useMaterial3: true,
    colorScheme: const ColorScheme.dark(
      primary: AppColors.cyan,
      onPrimary: AppColors.onCyan,
      secondary: AppColors.amber,
      surface: AppColors.surface,
      error: AppColors.coral,
    ),
    scaffoldBackgroundColor: AppColors.bg,
  );
  return base.copyWith(
    textTheme: base.textTheme.apply(
      bodyColor: AppColors.text,
      displayColor: AppColors.text,
    ),
    tooltipTheme: TooltipThemeData(
      decoration: BoxDecoration(
        color: AppColors.surfaceHi,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppColors.strokeHi),
      ),
      textStyle: const TextStyle(color: AppColors.text, fontSize: 12),
    ),
    sliderTheme: const SliderThemeData(
      trackHeight: 4,
      activeTrackColor: AppColors.cyan,
      inactiveTrackColor: AppColors.stroke,
      thumbColor: AppColors.cyan,
      overlayColor: Color(0x2222D3EE),
      thumbShape: RoundSliderThumbShape(enabledThumbRadius: 8),
      valueIndicatorColor: AppColors.cyan,
    ),
  );
}
