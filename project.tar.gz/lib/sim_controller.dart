// Simulation controller: owns the engine, objects, probes and settings.
// برمجة وتطوير: حسين خالد حميد

import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';

import 'engine/sim_objects.dart';
import 'engine/wave_engine.dart';

class ProbeData {
  static const int length = 220;
  final Float32List buf = Float32List(length);
  int head = 0;
  int count = 0;
  double amplitude = 0;
  double frequency = 0;

  void reset() {
    buf.fillRange(0, length, 0);
    head = 0;
    count = 0;
    amplitude = 0;
    frequency = 0;
  }

  void push(double v, double frameDt) {
    buf[head] = v;
    head = (head + 1) % length;
    if (count < length) count++;
    // stats
    double maxAbs = 0;
    for (int k = 0; k < count; k++) {
      final a = buf[k].abs();
      if (a > maxAbs) maxAbs = a;
    }
    amplitude = maxAbs;
    if (maxAbs < 0.004 || count < 30) {
      frequency = 0;
      return;
    }
    // zero crossings with hysteresis, oldest -> newest
    final th = maxAbs * 0.15;
    int state = 0;
    int crossings = 0;
    int first = -1, last = -1;
    for (int k = 0; k < count; k++) {
      final idx = (head - count + k + length * 2) % length;
      final s = buf[idx];
      int ns = state;
      if (s > th) ns = 1;
      if (s < -th) ns = -1;
      if (state != 0 && ns != state) {
        crossings++;
        if (first < 0) first = k;
        last = k;
      }
      state = ns;
    }
    if (crossings >= 2 && last > first) {
      final span = (last - first) * frameDt;
      frequency = (crossings - 1) / 2 / span;
    } else {
      frequency = 0;
    }
  }

  double at(int k) => buf[(head - count + k + length * 2) % length];
}

class Preset {
  final String ar;
  final String en;
  final String desc;
  final IconData icon;
  final List<Color> colors;
  const Preset(this.ar, this.en, this.desc, this.icon, this.colors);
}

const presets = <Preset>[
  Preset('تداخل مصدرين', 'Interference', 'مصدران متماسكان يكوّنان خطوط تداخل بنّاء وهدّام',
      Icons.bubble_chart, [Color(0xFF36E2F5), Color(0xFF3B82F6)]),
  Preset('الانعكاس', 'Reflection', 'ارتداد الأمواج عن الجدران الصلبة وتغيّر اتجاهها',
      Icons.flip, [Color(0xFF8B5CF6), Color(0xFF36E2F5)]),
  Preset('حيود شق مفرد', 'Single slit', 'انحناء الموجة وانتشارها بعد مرورها من فتحة ضيقة',
      Icons.unfold_more, [Color(0xFF22D3EE), Color(0xFF10B981)]),
  Preset('شق مزدوج (يونغ)', 'Double slit', 'تجربة يونغ: حيود وتداخل من شقّين',
      Icons.view_column, [Color(0xFFF472B6), Color(0xFF8B5CF6)]),
  Preset('الانكسار بالعدسة', 'Lens refraction', 'تباطؤ الموجة داخل العدسة وتجمّعها في البؤرة',
      Icons.lens_blur, [Color(0xFFFBBF24), Color(0xFFF472B6)]),
  Preset('المنشور', 'Prism', 'انحراف مسار الموجة عند عبورها وسطاً أبطأ',
      Icons.change_history, [Color(0xFFFB923C), Color(0xFFFBBF24)]),
  Preset('التشتت', 'Scattering', 'إعادة توزيع اتجاهات الموجة عند سطح خشن',
      Icons.grain, [Color(0xFF34D399), Color(0xFF36E2F5)]),
  Preset('الامتصاص', 'Absorption', 'مقارنة بين جدار يعكس الموجة ومادة تمتص طاقتها',
      Icons.texture, [Color(0xFFEF4444), Color(0xFF8B5CF6)]),
];

class ColorSchemeInfo {
  final String name;
  final List<Color> swatch;
  const ColorSchemeInfo(this.name, this.swatch);
}

const colorSchemes = <ColorSchemeInfo>[
  ColorSchemeInfo('محيط', [Color(0xFF05213F), Color(0xFF2CB4E6), Color(0xFFEBFFFF)]),
  ColorSchemeInfo('شفق', [Color(0xFF3C0A6E), Color(0xFF1EAAAA), Color(0xFFC8FFE6)]),
  ColorSchemeInfo('حراري', [Color(0xFF143CFF), Color(0xFF08080E), Color(0xFFFFE678)]),
  ColorSchemeInfo('كلاسيك', [Color(0xFF002828), Color(0xFF008080), Color(0xFF78FFFF)]),
];

class SimController extends ChangeNotifier {
  final WaveEngine engine = WaveEngine();
  final List<SimObject> objects = [];
  final Map<int, ProbeData> probes = {};

  /// Ticks every animation frame (canvas + probes listen to this).
  final ValueNotifier<int> frame = ValueNotifier<int>(0);

  SimObject? selected;
  bool paused = false;
  bool view3D = false;
  int speed = 2; // steps per frame
  double frequency = 3.0;
  double amplitude = 1.0;
  double damping = 0.0;
  double brightness = 0.75;
  double heightScale = 1.0;
  int colorScheme = 0;
  bool absorbingEdges = true;
  int presetIndex = -1;

  // 3D camera
  double yaw = -0.65;
  double pitch = 0.95;
  double zoom = 1.0;

  SimController() {
    loadPreset(0);
  }

  double get frameDt => speed * WaveEngine.dt;
  double get wavelengthCells => WaveEngine.speedCellsPerSecond / frequency;

  // ---------------------------------------------------------------- loop

  void tick() {
    if (!paused) {
      for (int s = 0; s < speed; s++) {
        engine.step();
        for (final o in objects) {
          if (o.kind.isSource) o.drive(engine, frequency, amplitude);
        }
      }
      for (final o in objects) {
        if (o.kind == ObjKind.probe) {
          probes.putIfAbsent(o.id, ProbeData.new)
              .push(engine.sample(o.pos.dx, o.pos.dy), frameDt);
        }
      }
    }
    frame.value++;
  }

  void rebuildMaps() {
    engine.absorbingEdges = absorbingEdges;
    engine.globalDamping = damping;
    engine.beginMaps();
    for (final o in objects) {
      o.rasterize(engine);
    }
    engine.endMaps();
  }

  // ------------------------------------------------------------ objects

  SimObject add(ObjKind kind, Offset pos, {bool vertical = false, double? length}) {
    final o = SimObject(kind, pos, vertical: vertical, length: length);
    o.bornAt = engine.time;
    objects.add(o);
    if (kind == ObjKind.probe) probes[o.id] = ProbeData();
    return o;
  }

  void addFromToolbar(ObjKind kind) {
    final k = objects.length % 5;
    final pos = Offset(90 + (k - 2) * 9.0, 90 + (k - 2) * 7.0);
    selected = add(kind, pos);
    rebuildMaps();
    notifyListeners();
  }

  SimObject? hitTest(Offset g, double tol) {
    SimObject? best;
    for (final o in objects.reversed) {
      if (o.hit(g, tol)) {
        if (best == null || o.hitPriority < best.hitPriority) best = o;
      }
    }
    return best;
  }

  void moveObject(SimObject o, Offset to) {
    const lo = 4.0, hi = WaveEngine.n - 5.0;
    o.pos = Offset(to.dx.clamp(lo, hi), to.dy.clamp(lo, hi));
    if (o.kind == ObjKind.probe) {
      probes[o.id]?.reset();
    } else if (!o.kind.isSource) {
      rebuildMaps();
    }
  }

  void select(SimObject? o) {
    if (selected == o) return;
    selected = o;
    notifyListeners();
  }

  void rotateSelected() {
    final o = selected;
    if (o == null || !o.kind.rotatable) return;
    o.vertical = !o.vertical;
    rebuildMaps();
    notifyListeners();
  }

  void deleteSelected() {
    final o = selected;
    if (o == null) return;
    objects.remove(o);
    probes.remove(o.id);
    selected = null;
    rebuildMaps();
    notifyListeners();
  }

  void poke(Offset g, {double amp = 1.6}) => engine.addPulse(g.dx, g.dy, amp);

  int probeNumber(SimObject p) {
    int k = 0;
    for (final o in objects) {
      if (o.kind == ObjKind.probe) {
        k++;
        if (identical(o, p)) return k;
      }
    }
    return k;
  }

  // ----------------------------------------------------------- settings

  void togglePause() {
    paused = !paused;
    notifyListeners();
  }

  void setView3D(bool v) {
    view3D = v;
    notifyListeners();
  }

  void setSpeed(int v) {
    speed = v;
    for (final p in probes.values) {
      p.reset();
    }
    notifyListeners();
  }

  void setFrequency(double v) {
    frequency = v;
    notifyListeners();
  }

  void setAmplitude(double v) {
    amplitude = v;
    notifyListeners();
  }

  void setDamping(double v) {
    damping = v;
    rebuildMaps();
    notifyListeners();
  }

  void setBrightness(double v) {
    brightness = v;
    notifyListeners();
  }

  void setHeightScale(double v) {
    heightScale = v;
    notifyListeners();
  }

  void setColorScheme(int v) {
    colorScheme = v;
    notifyListeners();
  }

  void setAbsorbingEdges(bool v) {
    absorbingEdges = v;
    rebuildMaps();
    notifyListeners();
  }

  void rotateCamera(double dYaw, double dPitch) {
    yaw += dYaw;
    pitch = (pitch + dPitch).clamp(0.25, 1.4);
  }

  void setZoom(double z) {
    zoom = z.clamp(0.6, 2.2);
  }

  void clearWaves() {
    engine.clearWaves();
    for (final p in probes.values) {
      p.reset();
    }
    for (final o in objects) {
      o.bornAt = engine.time;
    }
    notifyListeners();
  }

  void clearAll() {
    objects.clear();
    probes.clear();
    selected = null;
    presetIndex = -1;
    engine.clearWaves();
    rebuildMaps();
    notifyListeners();
  }

  // ------------------------------------------------------------- presets

  void loadPreset(int i) {
    objects.clear();
    probes.clear();
    selected = null;
    engine.clearWaves();
    presetIndex = i;
    absorbingEdges = true;
    switch (i) {
      case 0: // interference
        frequency = 3.0;
        add(ObjKind.pointSource, const Offset(72, 66));
        add(ObjKind.pointSource, const Offset(108, 66));
        add(ObjKind.probe, const Offset(90, 128));
        add(ObjKind.probe, const Offset(118, 120));
      case 1: // reflection
        frequency = 2.6;
        add(ObjKind.pointSource, const Offset(70, 70));
        add(ObjKind.wall, const Offset(92, 124), length: 110);
        add(ObjKind.wall, const Offset(140, 70), vertical: true, length: 90);
        add(ObjKind.probe, const Offset(70, 108));
      case 2: // single slit
        frequency = 3.0;
        add(ObjKind.lineSource, const Offset(90, 30), length: 150);
        add(ObjKind.singleSlit, const Offset(90, 66));
        add(ObjKind.probe, const Offset(90, 130));
      case 3: // double slit
        frequency = 3.4;
        add(ObjKind.lineSource, const Offset(90, 30), length: 150);
        add(ObjKind.doubleSlit, const Offset(90, 62));
        add(ObjKind.probe, const Offset(90, 140));
        add(ObjKind.probe, const Offset(112, 140));
      case 4: // lens
        frequency = 3.2;
        add(ObjKind.lineSource, const Offset(90, 28), length: 120);
        add(ObjKind.lens, const Offset(90, 70), length: 96);
        add(ObjKind.probe, const Offset(90, 128));
      case 5: // prism
        frequency = 3.2;
        add(ObjKind.lineSource, const Offset(28, 92), vertical: true, length: 96);
        add(ObjKind.prism, const Offset(90, 96));
        add(ObjKind.probe, const Offset(146, 118));
      case 6: // scattering
        frequency = 3.0;
        add(ObjKind.lineSource, const Offset(90, 30), length: 120);
        add(ObjKind.scatterer, const Offset(90, 96));
        add(ObjKind.probe, const Offset(90, 146));
      case 7: // absorption
        frequency = 2.8;
        add(ObjKind.lineSource, const Offset(90, 30), length: 150);
        add(ObjKind.absorber, const Offset(56, 104));
        add(ObjKind.wall, const Offset(126, 104), length: 48);
        add(ObjKind.probe, const Offset(56, 66));
        add(ObjKind.probe, const Offset(126, 66));
    }
    rebuildMaps();
    notifyListeners();
  }

  @override
  void dispose() {
    frame.dispose();
    super.dispose();
  }
}

double clampD(double v, double lo, double hi) => math.min(hi, math.max(lo, v));
