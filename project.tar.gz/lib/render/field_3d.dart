// 3D renderer: a real height-field mesh drawn with ui.Vertices (GPU),
// with an orbit camera (pitch & yaw), diffuse + specular lighting.

import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../engine/sim_objects.dart';
import '../engine/wave_engine.dart';
import '../sim_controller.dart';
import '../theme.dart';
import 'palette.dart';

class Mesh3D {
  static const int step = 2;
  static const int m = WaveEngine.n ~/ step; // 90 × 90 vertices

  final Float32List positions = Float32List(m * m * 2);
  final Int32List colors = Int32List(m * m);
  final Float32List heights = Float32List(m * m);
  final Float32List values = Float32List(m * m);
  final Uint8List types = Uint8List(m * m);

  Uint16List? _indices;
  double _yawCache = double.nan;

  Uint16List _indicesFor(double yaw) {
    if (_indices != null && (yaw - _yawCache).abs() < 0.015) return _indices!;
    _yawCache = yaw;
    const q = m - 1;
    final sy = math.sin(yaw), cy = math.cos(yaw);
    final depth = Float64List(q * q);
    for (int i = 0; i < q; i++) {
      for (int j = 0; j < q; j++) {
        final x = (j + 0.5) / q * 2 - 1;
        final z = (i + 0.5) / q * 2 - 1;
        depth[i * q + j] = x * sy + z * cy;
      }
    }
    final order = List<int>.generate(q * q, (k) => k);
    order.sort((a, b) => depth[b].compareTo(depth[a])); // far -> near
    final idx = Uint16List(q * q * 6);
    int p = 0;
    for (final k in order) {
      final i = k ~/ q, j = k % q;
      final v00 = i * m + j, v01 = v00 + 1, v10 = v00 + m, v11 = v10 + 1;
      idx[p++] = v00;
      idx[p++] = v01;
      idx[p++] = v11;
      idx[p++] = v00;
      idx[p++] = v11;
      idx[p++] = v10;
    }
    return _indices = idx;
  }

  void paint(Canvas canvas, Size size, SimController c) {
    final rect = Offset.zero & size;
    // background
    canvas.drawRect(
      rect,
      Paint()
        ..shader = const LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF1A1440), Color(0xFF0A1630), Color(0xFF040915)],
        ).createShader(rect),
    );

    final e = c.engine;
    const n = WaveEngine.n;
    final lut = Palette.luts[c.colorScheme];
    final cx = size.width / 2, cyS = size.height * 0.53;
    final f = math.min(size.width, size.height) * 1.05 * c.zoom;
    const camD = 3.1;
    final sy = math.sin(c.yaw), cyw = math.cos(c.yaw);
    final sp = math.sin(c.pitch), cp = math.cos(c.pitch);
    final hs = 0.17 * c.heightScale;

    Offset project(double x, double y, double z) {
      final x1 = x * cyw - z * sy;
      final z1 = x * sy + z * cyw;
      final y2 = y * cp + z1 * sp;
      final z2 = -y * sp + z1 * cp;
      final d = camD + z2;
      return Offset(cx + f * x1 / d, cyS - f * y2 / d);
    }

    // shadow under the tank
    final sh0 = project(-1, -0.08, -1), sh1 = project(1, -0.08, 1);
    final sh2 = project(1, -0.08, -1), sh3 = project(-1, -0.08, 1);
    final shadow = Path()
      ..moveTo(sh0.dx, sh0.dy)
      ..lineTo(sh2.dx, sh2.dy)
      ..lineTo(sh1.dx, sh1.dy)
      ..lineTo(sh3.dx, sh3.dy)
      ..close();
    canvas.drawPath(
      shadow,
      Paint()
        ..color = Colors.black.withValues(alpha: 0.55)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18),
    );

    // pass 1: sample heights
    final b = c.brightness;
    for (int i = 0; i < m; i++) {
      for (int j = 0; j < m; j++) {
        final gi = math.min(n - 1, i * step), gj = math.min(n - 1, j * step);
        final src = gi * n + gj;
        final k = i * m + j;
        final ct = e.cell[src];
        types[k] = ct;
        if (ct == CellType.wall) {
          heights[k] = 0.075;
          values[k] = 0;
        } else {
          double v = e.u[src] * b;
          // soft-clip heights so strong sources don't spike
          v = v / (1 + v.abs() * 0.6) * 1.6;
          values[k] = v;
          heights[k] = v * hs;
        }
      }
    }

    // pass 2: positions + lighting
    const lx = -0.45, ly = 0.78, lz = -0.43; // light dir (normalized-ish)
    final hxv = lx, hyv = ly + 1, hzv = lz;
    final hl = math.sqrt(hxv * hxv + hyv * hyv + hzv * hzv);
    final hx = hxv / hl, hy = hyv / hl, hz = hzv / hl;
    const g = (m - 1) / 4.0;
    for (int i = 0; i < m; i++) {
      for (int j = 0; j < m; j++) {
        final k = i * m + j;
        final x = j / (m - 1) * 2 - 1;
        final z = i / (m - 1) * 2 - 1;
        final y = heights[k];
        final p = project(x, y, z);
        positions[k * 2] = p.dx;
        positions[k * 2 + 1] = p.dy;

        final hl0 = heights[i * m + math.max(0, j - 1)];
        final hr0 = heights[i * m + math.min(m - 1, j + 1)];
        final hu0 = heights[math.max(0, i - 1) * m + j];
        final hd0 = heights[math.min(m - 1, i + 1) * m + j];
        double nx = -(hr0 - hl0) * g, ny = 1, nz = -(hd0 - hu0) * g;
        final nl = math.sqrt(nx * nx + ny * ny + nz * nz);
        nx /= nl;
        ny /= nl;
        nz /= nl;
        final diff = math.max(0.0, nx * lx + ny * ly + nz * lz);
        final ndh = math.max(0.0, nx * hx + ny * hy + nz * hz);
        final spec = math.pow(ndh, 40).toDouble() * 0.85;
        final shade = 0.32 + 0.85 * diff;

        int r, gg, bb;
        final ct = types[k];
        if (ct == CellType.wall) {
          r = 190;
          gg = 200;
          bb = 220;
        } else {
          final vv = values[k];
          final li = Palette.index(vv >= 0 ? math.sqrt(vv) : -math.sqrt(-vv)) * 3;
          r = lut[li];
          gg = lut[li + 1];
          bb = lut[li + 2];
          if (ct == CellType.absorber) {
            r = (r * 40 + 90 * 60) ~/ 100;
            gg = (gg * 40 + 14 * 60) ~/ 100;
            bb = (bb * 40 + 40 * 60) ~/ 100;
          } else if (ct == CellType.medium) {
            r = (r * 72 + 255 * 28) ~/ 100;
            gg = (gg * 72 + 196 * 28) ~/ 100;
            bb = (bb * 72 + 96 * 28) ~/ 100;
          }
        }
        final sAdd = spec * 255;
        final rr = (r * shade + sAdd).clamp(0, 255).toInt();
        final gr = (gg * shade + sAdd).clamp(0, 255).toInt();
        final br = (bb * shade + sAdd).clamp(0, 255).toInt();
        colors[k] = (0xFF << 24) | (rr << 16) | (gr << 8) | br;
      }
    }

    final verts = ui.Vertices.raw(
      ui.VertexMode.triangles,
      positions,
      colors: colors,
      indices: _indicesFor(c.yaw),
    );
    canvas.drawVertices(verts, BlendMode.dst, Paint());

    // glass rim of the tank
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.white.withValues(alpha: 0.28);
    final c00 = project(-1, 0, -1), c01 = project(1, 0, -1);
    final c11 = project(1, 0, 1), c10 = project(-1, 0, 1);
    canvas.drawPath(
      Path()
        ..moveTo(c00.dx, c00.dy)
        ..lineTo(c01.dx, c01.dy)
        ..lineTo(c11.dx, c11.dy)
        ..lineTo(c10.dx, c10.dy)
        ..close(),
      rim,
    );

    // sources as glowing pillars, probes as beacons
    double wx(double gx) => gx / (n - 1) * 2 - 1;
    for (final o in c.objects) {
      if (o.kind.isSource) {
        final pts = o.kind == ObjKind.lineSource
            ? [o.fromLocal(-o.length / 2, 0), o.pos, o.fromLocal(o.length / 2, 0)]
            : o.sourcePoints;
        if (o.kind == ObjKind.lineSource) {
          final a = project(wx(pts[0].dx), 0.12, wx(pts[0].dy));
          final bb = project(wx(pts[2].dx), 0.12, wx(pts[2].dy));
          canvas.drawLine(
            a,
            bb,
            Paint()
              ..color = AppColors.cyan.withValues(alpha: 0.6)
              ..strokeWidth = 8
              ..strokeCap = StrokeCap.round
              ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
          );
          canvas.drawLine(
            a,
            bb,
            Paint()
              ..color = Colors.white
              ..strokeWidth = 3
              ..strokeCap = StrokeCap.round,
          );
          continue;
        }
        for (final p in pts) {
          final bottom = project(wx(p.dx), 0, wx(p.dy));
          final top = project(wx(p.dx), 0.32, wx(p.dy));
          canvas.drawLine(
            bottom,
            top,
            Paint()
              ..color = AppColors.pink.withValues(alpha: 0.55)
              ..strokeWidth = 10
              ..strokeCap = StrokeCap.round
              ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
          );
          canvas.drawLine(
            bottom,
            top,
            Paint()
              ..shader = const LinearGradient(
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
                colors: [Color(0xFFD946EF), Color(0xFFF9A8D4)],
              ).createShader(Rect.fromPoints(bottom, top).inflate(4))
              ..strokeWidth = 5
              ..strokeCap = StrokeCap.round,
          );
        }
      } else if (o.kind == ObjKind.probe) {
        final color = probeColor(c.probeNumber(o));
        final y = e.sample(o.pos.dx, o.pos.dy) * b * hs + 0.06;
        final p = project(wx(o.pos.dx), y, wx(o.pos.dy));
        canvas.drawCircle(
          p,
          10,
          Paint()
            ..color = color.withValues(alpha: 0.5)
            ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 6),
        );
        canvas.drawCircle(p, 5, Paint()..color = color);
        canvas.drawCircle(p - const Offset(1.5, 1.5), 1.8,
            Paint()..color = Colors.white.withValues(alpha: 0.9));
      }
    }
  }
}

class Field3DPainter extends CustomPainter {
  Field3DPainter(this.c, this.mesh) : super(repaint: c.frame);
  final SimController c;
  final Mesh3D mesh;

  @override
  void paint(Canvas canvas, Size size) {
    canvas.save();
    canvas.clipRect(Offset.zero & size);
    mesh.paint(canvas, size, c);
    canvas.restore();
  }

  @override
  bool shouldRepaint(covariant Field3DPainter old) => true;
}
