// 2D renderer: wave amplitude -> RGBA texture, plus vector overlays.

import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../engine/sim_objects.dart';
import '../engine/wave_engine.dart';
import '../sim_controller.dart';
import '../theme.dart';
import 'palette.dart';

class Field2DRenderer extends ChangeNotifier {
  final Uint8List pixels = Uint8List(WaveEngine.size * 4);
  ui.Image? image;
  bool _pending = false;
  bool _disposed = false;

  void update(SimController c) {
    if (_pending || _disposed) return;
    _fill(c);
    _pending = true;
    ui.decodeImageFromPixels(
      pixels,
      WaveEngine.n,
      WaveEngine.n,
      ui.PixelFormat.rgba8888,
      (img) {
        _pending = false;
        if (_disposed) {
          img.dispose();
          return;
        }
        image?.dispose();
        image = img;
        notifyListeners();
      },
    );
  }

  void _fill(SimController c) {
    final e = c.engine;
    final u = e.u;
    final cells = e.cell;
    final lut = Palette.luts[c.colorScheme];
    final b = c.brightness;
    final px = pixels;
    for (int i = 0; i < WaveEngine.size; i++) {
      final p = i * 4;
      final ct = cells[i];
      if (ct == CellType.wall) {
        px[p] = 176;
        px[p + 1] = 188;
        px[p + 2] = 208;
        px[p + 3] = 255;
        continue;
      }
      // perceptual tone-mapping: lift weak waves, compress strong ones
      double v = u[i] * b;
      v = v >= 0 ? math.sqrt(v) : -math.sqrt(-v);
      if (v > 1) v = 1;
      if (v < -1) v = -1;
      final k = ((v + 1) * 127.5).toInt() * 3;
      int r = lut[k], g = lut[k + 1], bl = lut[k + 2];
      if (ct == CellType.absorber) {
        r = (r * 40 + 70 * 60) ~/ 100;
        g = (g * 40 + 10 * 60) ~/ 100;
        bl = (bl * 40 + 30 * 60) ~/ 100;
      } else if (ct == CellType.medium) {
        r = (r * 76 + 255 * 24) ~/ 100;
        g = (g * 76 + 196 * 24) ~/ 100;
        bl = (bl * 76 + 96 * 24) ~/ 100;
      }
      px[p] = r;
      px[p + 1] = g;
      px[p + 2] = bl;
      px[p + 3] = 255;
    }
  }

  @override
  void dispose() {
    _disposed = true;
    image?.dispose();
    image = null;
    super.dispose();
  }
}

class Field2DPainter extends CustomPainter {
  Field2DPainter(this.c, this.r) : super(repaint: Listenable.merge([r, c.frame]));
  final SimController c;
  final Field2DRenderer r;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final img = r.image;
    if (img != null) {
      canvas.drawImageRect(
        img,
        Rect.fromLTWH(0, 0, WaveEngine.n.toDouble(), WaveEngine.n.toDouble()),
        rect,
        Paint()..filterQuality = FilterQuality.medium,
      );
    } else {
      canvas.drawRect(rect, Paint()..color = const Color(0xFF06244F));
    }
    paintOverlays(canvas, rect, c);
  }

  @override
  bool shouldRepaint(covariant Field2DPainter old) => old.c != c || old.r != r;
}

// ------------------------------------------------------------------ overlays

void paintOverlays(Canvas canvas, Rect rect, SimController c) {
  final cell = rect.width / WaveEngine.n;
  Offset s(Offset g) => rect.topLeft + (g + const Offset(0.5, 0.5)) * cell;
  final t = c.engine.time;
  for (final o in c.objects) {
    _drawObject(canvas, o, s, cell, t, c);
  }
  final sel = c.selected;
  if (sel != null && c.objects.contains(sel)) {
    _drawSelection(canvas, sel, s, cell, t);
  }
}

Path _poly(List<Offset> pts) {
  final p = Path()..moveTo(pts.first.dx, pts.first.dy);
  for (final q in pts.skip(1)) {
    p.lineTo(q.dx, q.dy);
  }
  return p..close();
}

void _glowDot(Canvas cv, Offset c, double cell, double pulse, Color color) {
  cv.drawCircle(
    c,
    cell * (5 + 1.5 * pulse),
    Paint()
      ..color = color.withValues(alpha: 0.35)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 2.5),
  );
  cv.drawCircle(
    c,
    cell * 3.4,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.2, cell * 0.7)
      ..color = color.withValues(alpha: 0.9),
  );
  cv.drawCircle(c, cell * 1.9, Paint()..color = Colors.white);
}

void _drawObject(Canvas cv, SimObject o, Offset Function(Offset) s, double cell,
    double t, SimController c) {
  final pulse = 0.5 + 0.5 * math.sin(t * math.pi * 2 * c.frequency);
  switch (o.kind) {
    case ObjKind.pointSource:
    case ObjKind.doubleSource:
      final pts = o.sourcePoints;
      if (pts.length == 2) {
        cv.drawLine(
          s(pts[0]),
          s(pts[1]),
          Paint()
            ..color = AppColors.cyan.withValues(alpha: 0.35)
            ..strokeWidth = math.max(1, cell * 0.5),
        );
      }
      for (final p in pts) {
        _glowDot(cv, s(p), cell, pulse, AppColors.cyan);
      }
    case ObjKind.lineSource:
      final a = s(o.fromLocal(-o.length / 2, 0));
      final b = s(o.fromLocal(o.length / 2, 0));
      cv.drawLine(
        a,
        b,
        Paint()
          ..color = AppColors.cyan.withValues(alpha: 0.45 + 0.2 * pulse)
          ..strokeWidth = cell * 5
          ..strokeCap = StrokeCap.round
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 2),
      );
      cv.drawLine(
        a,
        b,
        Paint()
          ..color = Colors.white
          ..strokeWidth = math.max(2, cell * 1.4)
          ..strokeCap = StrokeCap.round,
      );
    case ObjKind.wall:
      final h = o.length / 2, w = SimObject.wallThick / 2 + 0.4;
      final path = _poly([
        s(o.fromLocal(-h, -w)),
        s(o.fromLocal(h, -w)),
        s(o.fromLocal(h, w)),
        s(o.fromLocal(-h, w)),
      ]);
      cv.drawPath(
        path,
        Paint()
          ..color = Colors.black.withValues(alpha: 0.45)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 1.5),
      );
      cv.drawPath(path, Paint()..color = const Color(0xFFD5DEEE));
      cv.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1
          ..color = Colors.white,
      );
    case ObjKind.singleSlit:
    case ObjKind.doubleSlit:
      final c0 = s(o.pos);
      cv.drawCircle(
        c0,
        cell * 4.2,
        Paint()
          ..color = Colors.black.withValues(alpha: 0.4)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 1.5),
      );
      cv.drawCircle(c0, cell * 3.4, Paint()..color = const Color(0xFFE2E8F0));
      cv.drawCircle(
        c0,
        cell * 3.4,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.5
          ..color = AppColors.violet,
      );
      final ax = o.axis * cell * 1.6, nn = o.normal * cell * 1.6;
      cv.drawLine(c0 - nn, c0 + nn,
          Paint()..color = AppColors.violet..strokeWidth = 1.6);
      if (o.kind == ObjKind.doubleSlit) {
        cv.drawLine(c0 - nn + ax, c0 + nn + ax,
            Paint()..color = AppColors.violet..strokeWidth = 1.6);
        cv.drawLine(c0 - nn - ax, c0 + nn - ax,
            Paint()..color = AppColors.violet..strokeWidth = 1.6);
      }
    case ObjKind.lens:
      final h = o.length / 2;
      final top = <Offset>[], bot = <Offset>[];
      for (int k = 0; k <= 32; k++) {
        final a = -h + 2 * h * k / 32;
        final tt = a / h;
        final b = SimObject.lensThick / 2 * (1 - tt * tt);
        top.add(s(o.fromLocal(a, -b)));
        bot.add(s(o.fromLocal(a, b)));
      }
      final path = _poly([...top, ...bot.reversed]);
      final bounds = path.getBounds();
      cv.drawPath(
        path,
        Paint()
          ..shader = LinearGradient(
            colors: [
              Colors.white.withValues(alpha: 0.28),
              AppColors.amber.withValues(alpha: 0.10),
              Colors.white.withValues(alpha: 0.22),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ).createShader(bounds),
      );
      cv.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = AppColors.amber.withValues(alpha: 0.95),
      );
    case ObjKind.prism:
      final h = o.prismHeight;
      final path = _poly([
        s(o.fromLocal(0, -2 * h / 3)),
        s(o.fromLocal(SimObject.prismSide / 2, h / 3)),
        s(o.fromLocal(-SimObject.prismSide / 2, h / 3)),
      ]);
      final bounds = path.getBounds();
      cv.drawPath(
        path,
        Paint()
          ..shader = SweepGradient(
            colors: [
              const Color(0x33FF4D6D),
              const Color(0x33FFD166),
              const Color(0x3306D6A0),
              const Color(0x33118AB2),
              const Color(0x33A78BFA),
              const Color(0x33FF4D6D),
            ],
          ).createShader(bounds),
      );
      cv.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.8
          ..strokeJoin = StrokeJoin.round
          ..shader = const LinearGradient(
            colors: [Color(0xFFFF4D6D), Color(0xFFFFD166), Color(0xFF06D6A0), Color(0xFFA78BFA)],
          ).createShader(bounds),
      );
    case ObjKind.absorber:
      const hs = SimObject.absorberSize / 2;
      final path = _poly([
        s(o.fromLocal(-hs, -hs)),
        s(o.fromLocal(hs, -hs)),
        s(o.fromLocal(hs, hs)),
        s(o.fromLocal(-hs, hs)),
      ]);
      final bounds = path.getBounds();
      cv.save();
      cv.clipPath(path);
      final hatch = Paint()
        ..color = const Color(0x55FF6B81)
        ..strokeWidth = 1;
      for (double d = -bounds.height; d < bounds.width; d += cell * 4) {
        cv.drawLine(Offset(bounds.left + d, bounds.bottom),
            Offset(bounds.left + d + bounds.height, bounds.top), hatch);
      }
      cv.restore();
      cv.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = const Color(0xFFFF6B81),
      );
    case ObjKind.scatterer:
      final c0 = s(o.pos);
      final r = (SimObject.scatterRadius + 4) * cell;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = const Color(0xAA34D399);
      const dashes = 28;
      for (int k = 0; k < dashes; k++) {
        final a0 = k * 2 * math.pi / dashes;
        cv.drawArc(Rect.fromCircle(center: c0, radius: r), a0,
            math.pi / dashes, false, paint);
      }
    case ObjKind.probe:
      final color = probeColor(c.probeNumber(o));
      final c0 = s(o.pos);
      cv.drawCircle(
        c0,
        cell * 4.5,
        Paint()
          ..color = color.withValues(alpha: 0.25)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 2),
      );
      final st = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = color;
      cv.drawCircle(c0, cell * 3.6, st);
      final l = cell * 6;
      cv.drawLine(c0 - Offset(l, 0), c0 - Offset(cell * 2, 0), st);
      cv.drawLine(c0 + Offset(cell * 2, 0), c0 + Offset(l, 0), st);
      cv.drawLine(c0 - Offset(0, l), c0 - Offset(0, cell * 2), st);
      cv.drawLine(c0 + Offset(0, cell * 2), c0 + Offset(0, l), st);
      cv.drawCircle(c0, cell * 0.9, Paint()..color = color);
  }
}

double selectionRadius(SimObject o) => switch (o.kind) {
      ObjKind.pointSource || ObjKind.probe => 9.0,
      ObjKind.doubleSource => SimObject.doubleSep / 2 + 8,
      ObjKind.lineSource || ObjKind.wall || ObjKind.lens => o.length / 2 + 4,
      ObjKind.singleSlit || ObjKind.doubleSlit => 10.0,
      ObjKind.prism => SimObject.prismSide * 0.62,
      ObjKind.absorber => SimObject.absorberSize * 0.75,
      ObjKind.scatterer => SimObject.scatterRadius + 9,
    };

void _drawSelection(Canvas cv, SimObject o, Offset Function(Offset) s,
    double cell, double t) {
  final c0 = s(o.pos);
  final r = selectionRadius(o) * cell;
  final rect = Rect.fromCircle(center: c0, radius: r);
  cv.drawCircle(
    c0,
    r,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6
      ..color = Colors.white.withValues(alpha: 0.12)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
  );
  final p = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 2
    ..strokeCap = StrokeCap.round
    ..shader = SweepGradient(
      colors: const [AppColors.cyan, AppColors.violet, AppColors.pink, AppColors.cyan],
      transform: GradientRotation(t * 1.5),
    ).createShader(rect);
  const segs = 24;
  for (int k = 0; k < segs; k++) {
    final a0 = k * 2 * math.pi / segs + t * 0.8;
    cv.drawArc(rect, a0, math.pi / segs * 1.1, false, p);
  }
}
