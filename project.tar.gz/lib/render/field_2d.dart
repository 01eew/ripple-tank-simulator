// 2D renderer: wave amplitude -> RGBA texture, plus vector overlays.

import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../engine/sim_objects.dart';
import '../engine/wave_engine.dart';
import '../sim_controller.dart';
import '../theme.dart';
import 'palette.dart';

class Field2DRenderer extends ChangeNotifier {
  final Uint8List pixels = Uint8List(WaveEngine.size * 4);
  ui.Image? image;
  bool _pending = false;
  bool _disposed = false;

  void update(SimController c) {
    if (_pending || _disposed) return;
    _fill(c);
    _pending = true;
    ui.decodeImageFromPixels(
      pixels,
      WaveEngine.n,
      WaveEngine.n,
      ui.PixelFormat.rgba8888,
      (img) {
        _pending = false;
        if (_disposed) {
          img.dispose();
          return;
        }
        image?.dispose();
        image = img;
        notifyListeners();
      },
    );
  }

  void _fill(SimController c) {
    final e = c.engine;
    final u = e.u;
    final cells = e.cell;
    final lut = Palette.luts[c.colorScheme];
    final b = c.brightness;
    final px = pixels;
    for (int i = 0; i < WaveEngine.size; i++) {
      final p = i * 4;
      final ct = cells[i];
      if (ct == CellType.wall) {
        // steel
        px[p] = 199;
        px[p + 1] = 210;
        px[p + 2] = 227;
        px[p + 3] = 255;
        continue;
      }
      // perceptual tone-mapping: lift weak waves, compress strong ones
      double v = u[i] * b;
      v = v >= 0 ? math.sqrt(v) : -math.sqrt(-v);
      if (v > 1) v = 1;
      if (v < -1) v = -1;
      final k = ((v + 1) * 127.5).toInt() * 3;
      int r = lut[k], g = lut[k + 1], bl = lut[k + 2];
      if (ct == CellType.absorber) {
        // coral-tinted, darkened
        r = (r * 45 + 120 * 55) ~/ 100;
        g = (g * 45 + 28 * 55) ~/ 100;
        bl = (bl * 45 + 44 * 55) ~/ 100;
      } else if (ct == CellType.medium) {
        // glass: slightly lighter, cyan-white tint
        r = (r * 78 + 200 * 22) ~/ 100;
        g = (g * 78 + 240 * 22) ~/ 100;
        bl = (bl * 78 + 250 * 22) ~/ 100;
      }
      px[p] = r;
      px[p + 1] = g;
      px[p + 2] = bl;
      px[p + 3] = 255;
    }
  }

  @override
  void dispose() {
    _disposed = true;
    image?.dispose();
    image = null;
    super.dispose();
  }
}

class Field2DPainter extends CustomPainter {
  Field2DPainter(this.c, this.r) : super(repaint: Listenable.merge([r, c.frame]));
  final SimController c;
  final Field2DRenderer r;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final img = r.image;
    if (img != null) {
      canvas.drawImageRect(
        img,
        Rect.fromLTWH(0, 0, WaveEngine.n.toDouble(), WaveEngine.n.toDouble()),
        rect,
        Paint()..filterQuality = FilterQuality.medium,
      );
    } else {
      canvas.drawRect(rect, Paint()..color = AppColors.bg);
    }
    paintOverlays(canvas, rect, c);
  }

  @override
  bool shouldRepaint(covariant Field2DPainter old) => old.c != c || old.r != r;
}

// ------------------------------------------------------------------ overlays

void paintOverlays(Canvas canvas, Rect rect, SimController c) {
  final cell = rect.width / WaveEngine.n;
  Offset s(Offset g) => rect.topLeft + (g + const Offset(0.5, 0.5)) * cell;
  final t = c.engine.time;
  for (final o in c.objects) {
    _drawObject(canvas, o, s, cell, t, c);
  }
  final sel = c.selected;
  if (sel != null && c.objects.contains(sel)) {
    drawSelectionRing(canvas, s(sel.pos), sel.selectionRadius * cell, t);
  }
}

Path _poly(List<Offset> pts) {
  final p = Path()..moveTo(pts.first.dx, pts.first.dy);
  for (final q in pts.skip(1)) {
    p.lineTo(q.dx, q.dy);
  }
  return p..close();
}

final _glassFill = Paint()..color = const Color(0x2EE6FBFF);
final _glassStroke = Paint()
  ..style = PaintingStyle.stroke
  ..strokeWidth = 1.6
  ..strokeJoin = StrokeJoin.round
  ..color = AppColors.cyan;

void _sourceDot(Canvas cv, Offset c, double cell, double pulse) {
  cv.drawCircle(
    c,
    cell * (5 + 1.5 * pulse),
    Paint()
      ..color = AppColors.amber.withValues(alpha: 0.35)
      ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 2.5),
  );
  cv.drawCircle(
    c,
    cell * 3.4,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = math.max(1.4, cell * 0.7)
      ..color = AppColors.amber,
  );
  cv.drawCircle(c, cell * 1.8, Paint()..color = AppColors.amber);
}

void _drawObject(Canvas cv, SimObject o, Offset Function(Offset) s, double cell,
    double t, SimController c) {
  final pulse = 0.5 + 0.5 * math.sin(t * math.pi * 2 * o.freq);
  switch (o.kind) {
    case ObjKind.pointSource:
    case ObjKind.doubleSource:
      final pts = o.sourcePoints;
      if (pts.length == 2) {
        cv.drawLine(
          s(pts[0]),
          s(pts[1]),
          Paint()
            ..color = AppColors.amber.withValues(alpha: 0.4)
            ..strokeWidth = math.max(1, cell * 0.5),
        );
      }
      for (final p in pts) {
        _sourceDot(cv, s(p), cell, pulse);
      }
    case ObjKind.lineSource:
      final a = s(o.fromLocal(-o.effLength / 2, 0));
      final b = s(o.fromLocal(o.effLength / 2, 0));
      cv.drawLine(
        a,
        b,
        Paint()
          ..color = AppColors.amber.withValues(alpha: 0.35 + 0.2 * pulse)
          ..strokeWidth = cell * 5
          ..strokeCap = StrokeCap.round
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 2),
      );
      cv.drawLine(
        a,
        b,
        Paint()
          ..color = AppColors.amber
          ..strokeWidth = math.max(2.5, cell * 1.4)
          ..strokeCap = StrokeCap.round,
      );
    case ObjKind.wall:
      final h = o.effLength / 2, w = SimObject.wallThick / 2 + 0.4;
      final path = _poly([
        s(o.fromLocal(-h, -w)),
        s(o.fromLocal(h, -w)),
        s(o.fromLocal(h, w)),
        s(o.fromLocal(-h, w)),
      ]);
      cv.drawPath(
        path,
        Paint()
          ..color = Colors.black.withValues(alpha: 0.5)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 1.5),
      );
      cv.drawPath(path, Paint()..color = AppColors.steel);
    case ObjKind.singleSlit:
    case ObjKind.doubleSlit:
      // barrier itself is in the texture; draw a steel grab-handle
      final c0 = s(o.pos);
      cv.drawCircle(
        c0,
        cell * 4.2,
        Paint()
          ..color = Colors.black.withValues(alpha: 0.45)
          ..maskFilter = MaskFilter.blur(BlurStyle.normal, cell * 1.5),
      );
      cv.drawCircle(c0, cell * 3.4, Paint()..color = AppColors.steel);
      final grip = Paint()
        ..color = AppColors.bg
        ..strokeWidth = 1.6
        ..strokeCap = StrokeCap.round;
      final ax = o.axis * cell * 1.3, nn = o.normal * cell * 1.6;
      cv.drawLine(c0 - nn, c0 + nn, grip);
      if (o.kind == ObjKind.doubleSlit) {
        cv.drawLine(c0 - nn + ax, c0 + nn + ax, grip);
        cv.drawLine(c0 - nn - ax, c0 + nn - ax, grip);
      }
    case ObjKind.lens:
      final h = o.effLength / 2;
      final top = <Offset>[], bot = <Offset>[];
      for (int k = 0; k <= 32; k++) {
        final a = -h + 2 * h * k / 32;
        final tt = a / h;
        final b = o.lensT / 2 * (1 - tt * tt);
        top.add(s(o.fromLocal(a, -b)));
        bot.add(s(o.fromLocal(a, b)));
      }
      final path = _poly([...top, ...bot.reversed]);
      cv.drawPath(path, _glassFill);
      cv.drawPath(path, _glassStroke);
    case ObjKind.prism:
      final h = o.prismHeight;
      final path = _poly([
        s(o.fromLocal(0, -2 * h / 3)),
        s(o.fromLocal(o.prismS / 2, h / 3)),
        s(o.fromLocal(-o.prismS / 2, h / 3)),
      ]);
      cv.drawPath(path, _glassFill);
      cv.drawPath(path, _glassStroke);
    case ObjKind.absorber:
      final hs = o.absS / 2;
      final path = _poly([
        s(o.fromLocal(-hs, -hs)),
        s(o.fromLocal(hs, -hs)),
        s(o.fromLocal(hs, hs)),
        s(o.fromLocal(-hs, hs)),
      ]);
      final bounds = path.getBounds();
      cv.save();
      cv.clipPath(path);
      final hatch = Paint()
        ..color = AppColors.coral.withValues(alpha: 0.35)
        ..strokeWidth = 1;
      for (double d = -bounds.height; d < bounds.width; d += cell * 4) {
        cv.drawLine(Offset(bounds.left + d, bounds.bottom),
            Offset(bounds.left + d + bounds.height, bounds.top), hatch);
      }
      cv.restore();
      cv.drawPath(
        path,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 1.6
          ..color = AppColors.coral,
      );
    case ObjKind.scatterer:
      final c0 = s(o.pos);
      final r = (o.scatR + 4) * cell;
      final paint = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..color = AppColors.steel.withValues(alpha: 0.7);
      const dashes = 28;
      for (int k = 0; k < dashes; k++) {
        final a0 = k * 2 * math.pi / dashes;
        cv.drawArc(Rect.fromCircle(center: c0, radius: r), a0,
            math.pi / dashes, false, paint);
      }
    case ObjKind.probe:
      final no = c.probeNumber(o);
      final color = probeColor(no);
      final c0 = s(o.pos);
      final st = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = color;
      cv.drawCircle(c0, cell * 3.6, Paint()..color = AppColors.bg.withValues(alpha: 0.55));
      cv.drawCircle(c0, cell * 3.6, st);
      final l = cell * 6;
      cv.drawLine(c0 - Offset(l, 0), c0 - Offset(cell * 2, 0), st);
      cv.drawLine(c0 + Offset(cell * 2, 0), c0 + Offset(l, 0), st);
      cv.drawLine(c0 - Offset(0, l), c0 - Offset(0, cell * 2), st);
      cv.drawLine(c0 + Offset(0, cell * 2), c0 + Offset(0, l), st);
      cv.drawCircle(c0, cell * 0.9, Paint()..color = color);
  }
}

/// Animated dashed cyan ring used to show the selected object (2D & 3D).
void drawSelectionRing(Canvas cv, Offset c0, double r, double t) {
  final rect = Rect.fromCircle(center: c0, radius: r);
  cv.drawCircle(
    c0,
    r,
    Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 6
      ..color = AppColors.cyan.withValues(alpha: 0.18)
      ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 4),
  );
  final p = Paint()
    ..style = PaintingStyle.stroke
    ..strokeWidth = 2
    ..strokeCap = StrokeCap.round
    ..color = AppColors.cyan;
  const segs = 24;
  for (int k = 0; k < segs; k++) {
    final a0 = k * 2 * math.pi / segs + t * 0.8;
    cv.drawArc(rect, a0, math.pi / segs * 1.1, false, p);
  }
}
