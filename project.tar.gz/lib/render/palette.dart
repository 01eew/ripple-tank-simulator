// Colour look-up tables for the wave field.

import 'dart:typed_data';

class _Stop {
  final double t;
  final int r, g, b;
  const _Stop(this.t, this.r, this.g, this.b);
}

const _schemes = <List<_Stop>>[
  // Ocean
  [
    _Stop(-1, 1, 4, 16),
    _Stop(-0.45, 4, 26, 62),
    _Stop(0, 6, 44, 92),
    _Stop(0.4, 38, 176, 230),
    _Stop(1, 236, 255, 255),
  ],
  // Aurora
  [
    _Stop(-1, 70, 12, 128),
    _Stop(-0.35, 34, 16, 74),
    _Stop(0, 12, 14, 40),
    _Stop(0.45, 30, 170, 170),
    _Stop(1, 205, 255, 230),
  ],
  // Thermal
  [
    _Stop(-1, 30, 90, 255),
    _Stop(-0.4, 12, 32, 124),
    _Stop(0, 8, 8, 14),
    _Stop(0.4, 205, 62, 22),
    _Stop(1, 255, 236, 130),
  ],
  // Classic teal
  [
    _Stop(-1, 0, 30, 34),
    _Stop(0, 0, 128, 128),
    _Stop(1, 130, 255, 255),
  ],
];

class Palette {
  /// 256 entries × RGB for each scheme.
  static final List<Uint8List> luts = [
    for (final s in _schemes) _build(s),
  ];

  static Uint8List _build(List<_Stop> stops) {
    final lut = Uint8List(256 * 3);
    for (int k = 0; k < 256; k++) {
      final v = k / 255 * 2 - 1;
      int j = 0;
      while (j < stops.length - 2 && v > stops[j + 1].t) {
        j++;
      }
      final a = stops[j], b = stops[j + 1];
      final f = ((v - a.t) / (b.t - a.t)).clamp(0.0, 1.0);
      lut[k * 3] = (a.r + (b.r - a.r) * f).round();
      lut[k * 3 + 1] = (a.g + (b.g - a.g) * f).round();
      lut[k * 3 + 2] = (a.b + (b.b - a.b) * f).round();
    }
    return lut;
  }

  static int index(double v) {
    final k = ((v + 1) * 127.5).round();
    return k < 0 ? 0 : (k > 255 ? 255 : k);
  }
}
