// Colour look-up tables for the wave field.

import 'dart:typed_data';

class _Stop {
  final double t;
  final int r, g, b;
  const _Stop(this.t, this.r, this.g, this.b);
}

const _schemes = <List<_Stop>>[
  // Signal — brand: ink navy → cyan → white crests
  [
    _Stop(-1, 2, 6, 14),
    _Stop(-0.45, 5, 22, 40),
    _Stop(0, 8, 40, 64),
    _Stop(0.45, 34, 211, 238),
    _Stop(1, 236, 254, 255),
  ],
  // Thermal — troughs sky blue, rest ink, crests amber
  [
    _Stop(-1, 125, 211, 252),
    _Stop(-0.4, 14, 90, 140),
    _Stop(0, 10, 15, 28),
    _Stop(0.4, 180, 110, 10),
    _Stop(1, 254, 240, 138),
  ],
  // Mono — print-friendly grayscale
  [
    _Stop(-1, 0, 0, 0),
    _Stop(0, 96, 104, 118),
    _Stop(1, 255, 255, 255),
  ],
  // Lab — classic ripple-tank teal
  [
    _Stop(-1, 0, 36, 40),
    _Stop(0, 0, 128, 128),
    _Stop(1, 160, 255, 255),
  ],
];

class Palette {
  /// 256 entries × RGB for each scheme.
  static final List<Uint8List> luts = [
    for (final s in _schemes) _build(s),
  ];

  static Uint8List _build(List<_Stop> stops) {
    final lut = Uint8List(256 * 3);
    for (int k = 0; k < 256; k++) {
      final v = k / 255 * 2 - 1;
      int j = 0;
      while (j < stops.length - 2 && v > stops[j + 1].t) {
        j++;
      }
      final a = stops[j], b = stops[j + 1];
      final f = ((v - a.t) / (b.t - a.t)).clamp(0.0, 1.0);
      lut[k * 3] = (a.r + (b.r - a.r) * f).round();
      lut[k * 3 + 1] = (a.g + (b.g - a.g) * f).round();
      lut[k * 3 + 2] = (a.b + (b.b - a.b) * f).round();
    }
    return lut;
  }

  static int index(double v) {
    final k = ((v + 1) * 127.5).round();
    return k < 0 ? 0 : (k > 255 ? 255 : k);
  }
}
