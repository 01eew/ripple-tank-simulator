// Draggable objects that live inside the ripple tank.
// برمجة وتطوير: حسين خالد حميد

import 'dart:math' as math;
import 'dart:ui';

import 'package:flutter/material.dart' show IconData, Icons;

import 'wave_engine.dart';

enum ObjKind {
  pointSource,
  doubleSource,
  lineSource,
  wall,
  singleSlit,
  doubleSlit,
  lens,
  prism,
  absorber,
  scatterer,
  probe,
}

extension ObjKindInfo on ObjKind {
  String get arName => switch (this) {
        ObjKind.pointSource => 'مصدر نقطي',
        ObjKind.doubleSource => 'مصدر مزدوج',
        ObjKind.lineSource => 'مصدر خطي',
        ObjKind.wall => 'جدار عاكس',
        ObjKind.singleSlit => 'شق مفرد',
        ObjKind.doubleSlit => 'شق مزدوج',
        ObjKind.lens => 'عدسة',
        ObjKind.prism => 'منشور',
        ObjKind.absorber => 'ماص',
        ObjKind.scatterer => 'سطح خشن',
        ObjKind.probe => 'مجس قياس',
      };

  String get enName => switch (this) {
        ObjKind.pointSource => 'Point source',
        ObjKind.doubleSource => 'Double source',
        ObjKind.lineSource => 'Line source',
        ObjKind.wall => 'Wall',
        ObjKind.singleSlit => 'Single slit',
        ObjKind.doubleSlit => 'Double slit',
        ObjKind.lens => 'Lens',
        ObjKind.prism => 'Prism',
        ObjKind.absorber => 'Absorber',
        ObjKind.scatterer => 'Scatterer',
        ObjKind.probe => 'Probe',
      };

  IconData get icon => switch (this) {
        ObjKind.pointSource => Icons.adjust,
        ObjKind.doubleSource => Icons.control_point_duplicate,
        ObjKind.lineSource => Icons.linear_scale,
        ObjKind.wall => Icons.horizontal_rule,
        ObjKind.singleSlit => Icons.unfold_more,
        ObjKind.doubleSlit => Icons.view_column,
        ObjKind.lens => Icons.lens_blur,
        ObjKind.prism => Icons.change_history,
        ObjKind.absorber => Icons.texture,
        ObjKind.scatterer => Icons.grain,
        ObjKind.probe => Icons.sensors,
      };

  bool get isSource =>
      this == ObjKind.pointSource ||
      this == ObjKind.doubleSource ||
      this == ObjKind.lineSource;

  bool get rotatable => this != ObjKind.pointSource && this != ObjKind.probe;

  /// Objects whose size can be changed by the user.
  bool get resizable => this != ObjKind.pointSource && this != ObjKind.probe;

  /// What the size slider means for this object (for the UI label).
  String get sizeLabel => switch (this) {
        ObjKind.singleSlit => 'عرض الشق',
        ObjKind.doubleSlit => 'عرض الشقين والمسافة بينهما',
        ObjKind.doubleSource => 'المسافة بين المصدرين',
        ObjKind.wall || ObjKind.lineSource => 'الطول',
        _ => 'الحجم',
      };
}

class SimObject {
  SimObject(this.kind, this.pos, {this.vertical = false, double? length})
      : id = _nextId++,
        length = length ?? _defaultLength(kind);

  static int _nextId = 1;

  static double _defaultLength(ObjKind k) => switch (k) {
        ObjKind.lineSource => 64,
        ObjKind.wall => 70,
        ObjKind.lens => 84,
        _ => 0,
      };

  // base geometry (grid cells) — multiplied by [scale]
  static const double wallThick = 3;
  static const double slitGap = 12;
  static const double dSlitGap = 6;
  static const double dSlitSep = 26;
  static const double doubleSep = 26;
  static const double lensThick = 24;
  static const double prismSide = 66;
  static const double absorberSize = 44;
  static const double scatterRadius = 24;

  static const double minScale = 0.5;
  static const double maxScale = 2.0;

  final int id;
  final ObjKind kind;
  Offset pos;
  bool vertical;
  double length;

  /// User size multiplier (0.5 … 2).
  double scale = 1.0;

  /// Source frequency in Hz (each source has its own).
  double freq = 3.0;

  double phase = 0;
  double bornAt = 0;
  double _phaseAcc = 0;

  List<Offset>? _dots;
  double _dotsScale = -1;

  // ------------------------------------------------------ effective sizes

  double get effLength => length * scale;
  double get lensT => lensThick * scale;
  double get prismS => prismSide * scale;
  double get absS => absorberSize * scale;
  double get scatR => scatterRadius * scale;
  double get slitGapW => slitGap * scale;
  double get dSlitGapW => dSlitGap * scale;
  double get dSlitSepW => dSlitSep * scale;
  double get srcSep => doubleSep * scale;
  double get prismHeight => prismS * math.sqrt(3) / 2;

  Offset get axis => vertical ? const Offset(0, 1) : const Offset(1, 0);
  Offset get normal => vertical ? const Offset(-1, 0) : const Offset(0, 1);

  /// Converts a grid point into this object's local (along, across) frame.
  (double, double) local(Offset p) {
    final d = p - pos;
    return (
      d.dx * axis.dx + d.dy * axis.dy,
      d.dx * normal.dx + d.dy * normal.dy,
    );
  }

  Offset fromLocal(double a, double b) => pos + axis * a + normal * b;

  List<Offset> get sourcePoints => switch (kind) {
        ObjKind.doubleSource => [
            fromLocal(-srcSep / 2, 0),
            fromLocal(srcSep / 2, 0),
          ],
        _ => [pos],
      };

  void resetPhase(double now) {
    bornAt = now;
    _phaseAcc = 0;
  }

  // ------------------------------------------------------------ hit test

  bool hit(Offset p, double tol) {
    final (a, b) = local(p);
    switch (kind) {
      case ObjKind.wall:
        return a.abs() <= effLength / 2 + tol && b.abs() <= wallThick / 2 + tol;
      case ObjKind.lineSource:
        return a.abs() <= effLength / 2 + tol && b.abs() <= tol;
      case ObjKind.singleSlit:
      case ObjKind.doubleSlit:
        return a.abs() <= 34 && b.abs() <= tol + 2;
      case ObjKind.lens:
        return a.abs() <= effLength / 2 + tol && b.abs() <= lensT / 2 + tol;
      case ObjKind.prism:
        return (p - pos).distance <= prismS * 0.45 + tol;
      case ObjKind.absorber:
        return a.abs() <= absS / 2 + tol && b.abs() <= absS / 2 + tol;
      case ObjKind.scatterer:
        return (p - pos).distance <= scatR + tol;
      case ObjKind.doubleSource:
        return a.abs() <= srcSep / 2 + tol && b.abs() <= tol;
      case ObjKind.pointSource:
      case ObjKind.probe:
        return (p - pos).distance <= tol + 2;
    }
  }

  /// Small things are grabbed before big areas.
  int get hitPriority => switch (kind) {
        ObjKind.probe => 0,
        ObjKind.pointSource || ObjKind.doubleSource => 1,
        ObjKind.lineSource => 2,
        ObjKind.wall || ObjKind.singleSlit || ObjKind.doubleSlit => 3,
        _ => 4,
      };

  /// Radius (grid cells) used for the selection ring.
  double get selectionRadius => switch (kind) {
        ObjKind.pointSource || ObjKind.probe => 9.0,
        ObjKind.doubleSource => srcSep / 2 + 8,
        ObjKind.lineSource || ObjKind.wall || ObjKind.lens => effLength / 2 + 4,
        ObjKind.singleSlit || ObjKind.doubleSlit => 10.0,
        ObjKind.prism => prismS * 0.62,
        ObjKind.absorber => absS * 0.75,
        ObjKind.scatterer => scatR + 9,
      };

  // ----------------------------------------------------------- rasterize

  void rasterize(WaveEngine e) {
    switch (kind) {
      case ObjKind.wall:
        _paint(e, effLength / 2 + 3,
            (a, b) => a.abs() <= effLength / 2 && b.abs() <= wallThick / 2,
            e.setWall);
      case ObjKind.singleSlit:
        _barrier(e, const [0], slitGapW);
      case ObjKind.doubleSlit:
        _barrier(e, [-dSlitSepW / 2, dSlitSepW / 2], dSlitGapW);
      case ObjKind.lens:
        final h = effLength / 2;
        final t2 = lensT / 2;
        _paint(e, h + 2, (a, b) {
          if (a.abs() > h) return false;
          final t = a / h;
          return b.abs() <= t2 * (1 - t * t);
        }, e.setMedium);
      case ObjKind.prism:
        final h = prismHeight;
        final s = prismS;
        _paint(e, s, (a, b) {
          // apex at b = -2h/3, base at b = +h/3
          if (b > h / 3 || b < -2 * h / 3) return false;
          final half = (b + 2 * h / 3) * (s / 2) / h;
          return a.abs() <= half;
        }, e.setMedium);
      case ObjKind.absorber:
        final hs = absS / 2;
        _paint(e, absS, (a, b) => a.abs() <= hs && b.abs() <= hs, e.setAbsorber);
      case ObjKind.scatterer:
        const n = WaveEngine.n;
        for (final d in scatterDots) {
          final cx = (pos.dx + d.dx).round();
          final cy = (pos.dy + d.dy).round();
          for (int oy = 0; oy < 2; oy++) {
            for (int ox = 0; ox < 2; ox++) {
              final x = cx + ox, y = cy + oy;
              if (x < 1 || y < 1 || x > n - 2 || y > n - 2) continue;
              e.setWall(y * n + x);
            }
          }
        }
      default:
        break;
    }
  }

  List<Offset> get scatterDots {
    if (_dots != null && _dotsScale == scale) return _dots!;
    final rnd = math.Random(id * 7919 + 17);
    final list = <Offset>[];
    final r0 = scatR;
    final count = (46 * scale * scale).round().clamp(12, 180);
    int guard = 0;
    while (list.length < count && guard++ < 4000) {
      final ang = rnd.nextDouble() * math.pi * 2;
      final r = math.sqrt(rnd.nextDouble()) * r0;
      final p = Offset(math.cos(ang) * r, math.sin(ang) * r);
      if (list.every((q) => (q - p).distance >= 5.2)) list.add(p);
    }
    _dotsScale = scale;
    return _dots = list;
  }

  void _paint(WaveEngine e, double radius, bool Function(double a, double b) inside,
      void Function(int i) set) {
    const n = WaveEngine.n;
    final x0 = math.max(1, (pos.dx - radius).floor());
    final x1 = math.min(n - 2, (pos.dx + radius).ceil());
    final y0 = math.max(1, (pos.dy - radius).floor());
    final y1 = math.min(n - 2, (pos.dy + radius).ceil());
    for (int y = y0; y <= y1; y++) {
      for (int x = x0; x <= x1; x++) {
        final (a, b) = local(Offset(x.toDouble(), y.toDouble()));
        if (inside(a, b)) set(y * n + x);
      }
    }
  }

  /// A barrier spanning the whole tank with gaps (slits) centered at [gaps].
  void _barrier(WaveEngine e, List<double> gaps, double gapWidth) {
    const n = WaveEngine.n;
    _paint(e, n.toDouble() * 1.5, (a, b) {
      if (b.abs() > wallThick / 2) return false;
      for (final g in gaps) {
        if ((a - g).abs() < gapWidth / 2) return false;
      }
      return true;
    }, e.setWall);
  }

  // -------------------------------------------------------------- drive

  /// Called once per simulation step. Uses a phase accumulator so the
  /// frequency can be changed live without a phase jump.
  void drive(WaveEngine e, double amp) {
    _phaseAcc += 2 * math.pi * freq * WaveEngine.dt;
    if (_phaseAcc > 2 * math.pi * 1000) _phaseAcc -= 2 * math.pi * 1000;
    final t = e.time - bornAt;
    final env = 1 - math.exp(-t * 3.5);
    final v = amp * env * math.sin(_phaseAcc + phase);
    switch (kind) {
      case ObjKind.pointSource:
        e.drive(pos.dx, pos.dy, v);
      case ObjKind.doubleSource:
        for (final p in sourcePoints) {
          e.drive(p.dx, p.dy, v);
        }
      case ObjKind.lineSource:
        final half = effLength / 2;
        final edge = math.max(4.0, effLength * 0.18);
        for (double s = -half; s <= half; s += 1) {
          final dEdge = half - s.abs();
          final w = dEdge >= edge
              ? 1.0
              : 0.5 - 0.5 * math.cos(math.pi * dEdge / edge);
          final p = fromLocal(s, 0);
          e.drive(p.dx, p.dy, v * w * 0.8, radius: 0.6);
        }
      default:
        break;
    }
  }
}
