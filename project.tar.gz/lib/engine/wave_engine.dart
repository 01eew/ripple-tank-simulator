// Ripple Tank Simulator — FDTD wave engine
// برمجة وتطوير: حسين خالد حميد — جامعة المعقل
//
// Solves the 2D scalar wave equation  ∂²u/∂t² = c²∇²u  on a 180×180 grid
// using a leap-frog finite-difference time-domain (FDTD) scheme with a
// 5-point Laplacian. All state lives in flat typed lists for speed.

import 'dart:math' as math;
import 'dart:typed_data';

/// Cell types stored in [WaveEngine.cell].
class CellType {
  static const int free = 0;
  static const int wall = 1; // hard reflector (u = 0)
  static const int absorber = 2; // strong damping
  static const int medium = 3; // slow medium (refraction)
}

class WaveEngine {
  static const int n = 180;
  static const int size = n * n;

  /// Courant number squared (c·dt/dx)². Must stay ≤ 0.5 for stability in 2D.
  static const double baseC2 = 0.25;

  /// Refractive index of the "water-glass" media (lenses, prisms).
  static const double mediumIndex = 1.7;

  /// Simulated seconds per step.
  static const double dt = 1 / 120;

  /// Width of the absorbing sponge layer at the borders.
  static const int sponge = 16;

  /// Wave speed in cells per simulated second (free space).
  static double get speedCellsPerSecond => math.sqrt(baseC2) / dt;

  Float32List u = Float32List(size);
  Float32List uPrev = Float32List(size);
  final Float32List c2 = Float32List(size);
  final Float32List damp = Float32List(size);
  final Uint8List cell = Uint8List(size);

  double time = 0;
  double globalDamping = 0; // 0..1
  bool absorbingEdges = true;

  WaveEngine() {
    beginMaps();
    endMaps();
  }

  // ---------------------------------------------------------------- maps

  void beginMaps() {
    cell.fillRange(0, size, CellType.free);
    c2.fillRange(0, size, baseC2);
  }

  void setMedium(int i) {
    if (cell[i] == CellType.wall) return;
    cell[i] = CellType.medium;
    c2[i] = baseC2 / (mediumIndex * mediumIndex);
  }

  void setWall(int i) {
    cell[i] = CellType.wall;
    c2[i] = 0;
  }

  void setAbsorber(int i) {
    if (cell[i] == CellType.wall) return;
    cell[i] = CellType.absorber;
  }

  /// Builds the per-cell damping map. Call after all objects rasterized.
  void endMaps() {
    final g = 1.0 - globalDamping * 0.012;
    for (int y = 0; y < n; y++) {
      for (int x = 0; x < n; x++) {
        final i = y * n + x;
        double d = g;
        if (absorbingEdges) {
          final e = math.min(math.min(x, y), math.min(n - 1 - x, n - 1 - y));
          if (e < sponge) {
            final t = (sponge - e) / sponge;
            d *= 1.0 - 0.16 * t * t;
          }
        }
        final ct = cell[i];
        if (ct == CellType.absorber) {
          d *= 0.92;
        } else if (ct == CellType.medium) {
          d *= 0.9988; // slight absorption inside media
        } else if (ct == CellType.wall) {
          u[i] = 0;
          uPrev[i] = 0;
        }
        damp[i] = d;
      }
    }
  }

  // ---------------------------------------------------------------- sim

  void clearWaves() {
    u.fillRange(0, size, 0);
    uPrev.fillRange(0, size, 0);
  }

  /// One leap-frog step. Writes u(t+dt) into the old buffer and swaps.
  void step() {
    final cur = u;
    final prev = uPrev;
    final cells = cell;
    final cc = c2;
    final dd = damp;
    for (int y = 1; y < n - 1; y++) {
      final row = y * n;
      for (int x = 1; x < n - 1; x++) {
        final i = row + x;
        if (cells[i] == CellType.wall) {
          prev[i] = 0;
          continue;
        }
        final c = cur[i];
        final lap = cur[i - 1] + cur[i + 1] + cur[i - n] + cur[i + n] - 4 * c;
        prev[i] = (2 * c - prev[i] + cc[i] * lap) * dd[i];
      }
    }
    u = prev;
    uPrev = cur;
    time += dt;
  }

  // ------------------------------------------------------------- sources

  /// Hard-drives a small disc of cells to [value] (oscillating source).
  void drive(double gx, double gy, double value, {double radius = 1.6}) {
    final cx = gx.round();
    final cy = gy.round();
    final r = radius.ceil();
    final r2 = radius * radius;
    for (int dy = -r; dy <= r; dy++) {
      final y = cy + dy;
      if (y < 1 || y > n - 2) continue;
      for (int dx = -r; dx <= r; dx++) {
        final x = cx + dx;
        if (x < 1 || x > n - 2) continue;
        if (dx * dx + dy * dy > r2) continue;
        final i = y * n + x;
        if (cell[i] == CellType.wall) continue;
        u[i] = value;
      }
    }
  }

  /// Adds a Gaussian bump (a "finger drop" in the tank).
  void addPulse(double gx, double gy, double amp, {double sigma = 2.6}) {
    final r = (sigma * 2.6).ceil();
    final cx = gx.round();
    final cy = gy.round();
    final s2 = 2 * sigma * sigma;
    for (int dy = -r; dy <= r; dy++) {
      final y = cy + dy;
      if (y < 1 || y > n - 2) continue;
      for (int dx = -r; dx <= r; dx++) {
        final x = cx + dx;
        if (x < 1 || x > n - 2) continue;
        final i = y * n + x;
        if (cell[i] == CellType.wall) continue;
        final w = amp * math.exp(-(dx * dx + dy * dy) / s2);
        u[i] += w;
        uPrev[i] += w;
      }
    }
  }

  double sample(double gx, double gy) {
    final x = gx.round().clamp(0, n - 1);
    final y = gy.round().clamp(0, n - 1);
    return u[y * n + x];
  }
}
