import 'package:flutter_test/flutter_test.dart';
import 'package:untitled/engine/wave_engine.dart';

void main() {
  test('wave engine stays stable', () {
    final e = WaveEngine();
    e.addPulse(90, 90, 1);
    for (int i = 0; i < 2000; i++) {
      e.step();
    }
    double maxAbs = 0;
    for (final v in e.u) {
      if (v.abs() > maxAbs) maxAbs = v.abs();
    }
    expect(maxAbs.isFinite, true);
    expect(maxAbs < 2, true);
  });
}
